# ○ 辛辰的附件表

> 辛辰的附件表（请按快捷键 Ctrl+F 输入视频标题来搜索内容）💕

✓ 和每期视频保持同步更新

✓ 你可以方便的在这里查阅并下载莫老师每期视频的附件

✓ **辛辰的主页：**

🙂 [B站（首发） ](https://space.bilibili.com/1995424953)  😀[西瓜视频](https://www.ixigua.com/home/303878777609358)  🤣[抖音短视频](https://v.douyin.com/MYjf1JM/)  😉[快手短视频](https://v.kuaishou.com/mRpRYy)  🙃[微博](https://weibo.com/u/7826133162)  😆[YOUTUBE](https://www.youtube.com/@zxmls)

#### ○ <font color="#DB7093">莫老师开通粉丝群啦，欢迎大家来玩玩！看不到二维码（[👉请戳这里👈](https://img10.360buyimg.com/babel/jfs/t20260307/170643/6/43337/21787/65e91d82F406336d7/205bab8b3f9dfcd1.jpg)）</font>

![粉丝群](https://img10.360buyimg.com/babel/jfs/t20260307/170643/6/43337/21787/65e91d82F406336d7/205bab8b3f9dfcd1.jpg)



***<font color="#00CAE1">● 注意！不要在网盘中在线解压任何文件！！会导致文件失效！！！</font>***

***<font color="#FF725C">● 注意！请将附件先转存到自己网盘再下载！！避免文件被和谐！！！！</font>***

================【快捷会员合租：戳下边】================

[ChatGPT Plus | Netflix | Disney+ | Spotify | Midjourney | Office 365](https://nf.video/gLlmQ)

=================【全场折扣码： zxmls】==================

<HR>

##### **EP161 - 全屋2.5G，有线无线混组！我找到了可能最适合极客的组网方案**

● <font color="#FF8C00">H68K软路由和蜂巢易网AP都属于极客DIY的定制小众产品，目前我已使用一段时间，稳定性很优秀，如果大家对这俩产品感兴趣，可以先加[粉丝群](https://img10.360buyimg.com/babel/jfs/t20260307/170643/6/43337/21787/65e91d82F406336d7/205bab8b3f9dfcd1.jpg)跟我说说，我会去跟厂家PY一下，争取搞到一波团购名额，价格会低于市面上所有的在售价</font>



<HR>

##### **EP160 - 游戏玩家的帧数提升利器？GHOST SPECTRE精简系统安装体验**

● GHOST SPECTRE（主页）：https://www.youtube.com/c/GHOSTSPECTRE/videos

● GHOST SPECTRE Win11 23H2 Update5：https://pan.quark.cn/s/987a06575f74



<HR>

##### **EP159 - 纯净无广告，又强又趁手的维护工具，FirPE使用和DIY指南**

● FirPE（官网）：https://firpe.cn/page-247

● FirPE：https://pan.quark.cn/s/4940601c52b5

● Edgeless插件下载：https://edgeless.work/%E6%8F%92%E4%BB%B6%E5%8C%85

● PE Tools（小工具集）：：https://cloud.189.cn/web/share?code=aMvE3uVVFFZz （访问码：4dby）（解压密码：zxmls，解压出来的pdf文件改后缀名为7z再解压一次）



<HR>

##### **EP158 - 电视盒子，但玩得挺花！火影HT2盒子刷机及多系统体验**

● <font color="#FF8C00">火影HT2盒子：</font>[点此查看](https://m.tb.cn/h.5Es06XIgqzcn1F8?tk=gVbQWmt1fcO )

● HT2 刷机工具：https://pan.quark.cn/s/ff7dd74088ca

● HT2 Android固件：https://pan.quark.cn/s/4f19ebd3dee0

● HT2 OpenWRT固件：https://pan.quark.cn/s/330cf1668b20

● HT2 Armbian固件：https://pan.quark.cn/s/13c2b2af96c1



<HR>

##### **EP157 - 用核显玩游戏怎么样？极摩客K8 8845HS拆机，及3A游戏体验**

● <font color="#FF8C00">极摩客K8迷你主机：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAbAJK1olXwQKVV1fDUoUAF8IGlodWgMHUFxaCUoSC19MRANLAjZbERscSkAJHTRQRA1CCVkdDwtCWhVLHTdNTwcKBENeCVAfUg8bA24JE1wQWAIAU19cDUMAQ2N8YitwJGV9FCk0bCtjWghMbDJPBWJhIBg-ehFxYW54XS1gLW9lDi4UaDkXdQ1BGhthFVt0NhcbTj9PfBxrGixCKX9iNio-CBRgXB9vYDxpW2NKNyg6VxV_UQl0fTgUNll2CwQ6ayh8RxhxbzJ1BHlANFwifjJ0eDBoUydzKnUCESokaBhjSwxUbzJPDnFxMwEqYR1PMzBtWl5hIwdXMURHfwNoBxhUTRMXJlAOWG5cOEgWAW8BGl8RWA4yZF5aOAp5A2oIElIRVAEyVW5dDkoeB2cJHFITWAEEZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXAF8LK1sUXQ4BVlxfAEoXH28NE1oWXRoCUl9UDEMWBGkLHVkTbQQDVVpUOHsnew51fgJ0VGALHQAfSSNsAQ1ofThAWgRGOlxYCRRTZyt7TlJxInxHBxcnX3s)



<HR>

##### **EP156 - 外边像Mac，里边装Mac，AYANEO AM01迷你主机黑苹果安装体验**

● <font color="#FF8C00">AYANEO AM01迷你主机：</font>[点此查看](https://m.tb.cn/h.5H8tHfK)

● AYANEO AM01 黑苹果EFI（@小明和他的女朋友）：https://pan.quark.cn/s/2f0d50e0c43f

● AYANEO AM01 黑苹果EFI（Github）：https://github.com/Xmingbai/AYANEO-AM01-Hackintosh

● macOS Ventura 13 系统镜像：https://pan.quark.cn/s/9799911b1831

● NoTouchID.kext（Github）：https://github.com/al3xtjames/NoTouchID

● NoTouchID.kext：https://pan.quark.cn/s/9f02f6a412f9

● BalenaEtcher（官网）：https://etcher.balena.io/

● BalenaEtcher：https://pan.quark.cn/s/dd0eb5dac656



<HR>

##### **EP155 - 利用PVE虚拟机，安装黑群晖和黑苹果，All In One运行5个系统（AIO打造第三集）**

● DSM7.21引导（来自@GXNAS）：https://pan.quark.cn/s/f29ca7a66bc2

● GXNAS博客：https://wp.gxnas.com/11849.html

● DSM7.21官方固件：https://pan.quark.cn/s/d90407800171

● img2kvm脚本：https://pan.quark.cn/s/634c129636d4

● MobaXterm（官网）：https://mobaxterm.mobatek.net

● MobaXterm：https://pan.quark.cn/s/e269ad2a5ae9

● 虚拟机专用MacOS系统镜像：https://pan.quark.cn/s/9e7ed6d26d09

● KVM-OpenCore引导：https://pan.quark.cn/s/5f26761f4850

○ 以下为需要敲的代码

#给img2kvm权限

```
chmod +x img2kvm
```

#执行磁盘格式转换（注意替换虚拟机ID）

```
./img2kvm DS918_7.21-69057.img 103 vm-103-disk-1
```

#在PVE Shell中编辑Opencore引导文件（注意替换虚拟机ID）

```
nano /etc/pve/qemu-server/104.conf
```

#Intel CPU添加这段到Opencore引导文件头部

```
args: -device isa-applesmc,osk="ourhardworkbythesewordsguardedpleasedontsteal(c)AppleComputerInc" -smbios type=2 -device usb-kbd,bus=ehci.0,port=2 -global nec-usb-xhci.msi=off -global ICH9-LPC.acpi-pci-hotplug-with-bridge-support=off -cpu host,vendor=GenuineIntel,+invtsc,+hypervisor,kvm=on,vmware-cpuid-freq=on
```

#AMD CPU添加这段到Opencore引导文件头部

```
args: -device isa-applesmc,osk="ourhardworkbythesewordsguardedpleasedontsteal(c)AppleComputerInc" -smbios type=2 -device usb-kbd,bus=ehci.0,port=2 -global nec-usb-xhci.msi=off -global ICH9-LPC.acpi-pci-hotplug-with-bridge-support=off -cpu Haswell-noTSX,vendor=GenuineIntel,+invtsc,+hypervisor,kvm=on,vmware-cpuid-freq=on
```

#修改ide0这行的media=cdrom为

```
cache=unsafe
```

#修改ide2这行的media=cdrom为

```
cache=unsafe
```

#启动OpenCore引导后输入

```
fs0:
```

#编辑OpenCore引导路径

```
System\Library\CoreServices\Boot.efi
```



<HR>

##### **EP154 - 利用PVE虚拟机，安装Windows和Linux系统，并优化配置（AIO打造第二集）**

● Windows镜像（MSDN）：https://visualstudio.microsoft.com/zh-hans/msdn-platforms

● Windows镜像（仓储站）：https://hellowindows.cn

● Win10LTSC镜像：https://pan.quark.cn/s/dac57b63096e

● VirtIO驱动镜像：https://pan.quark.cn/s/fd419d8611bd

● Ubuntu（官网）：https://cn.ubuntu.com/download

● Ubuntu20.4镜像：https://pan.quark.cn/s/c1bba37ab249

● MobaXterm（官网）：https://mobaxterm.mobatek.net

● MobaXterm：https://pan.quark.cn/s/e269ad2a5ae9

● pve_source脚本：https://pan.quark.cn/s/1fef567176e6

○ 以下为需要敲的代码

#解压pve_source脚本

```
tar zxvf pve_source.tar.gz
```

#运行pve_source脚本

```
./pve_source
```



<HR>

##### **EP153 - 利用PVE虚拟机，来打造属于自己的All In One系统吧！（AIO打造第一集）**

● Proxmox VE虚拟机（官网）：https://pve.proxmox.com

● Proxmox VE虚拟机（安装镜像）：https://pan.quark.cn/s/f62df17918a3

● img2kvm脚本：https://pan.quark.cn/s/634c129636d4

● BalenaEtcher（官网）：https://etcher.balena.io/

● BalenaEtcher：https://pan.quark.cn/s/dd0eb5dac656

● MobaXterm（官网）：https://mobaxterm.mobatek.net

● MobaXterm：https://pan.quark.cn/s/e269ad2a5ae9

● OpenWRT（安装镜像）：https://pan.quark.cn/s/63cda803abeb

○ 以下为需要敲的代码

#给img2kvm权限

```
chmod +x img2kvm
```

#执行磁盘格式转换

```
./img2kvm openwrt-23.05.img 100 vm-100-disk-1
```

#编辑OpenWRT的IP地址

```
vi /etc/config/network
```



<HR>

##### **EP152 - 把i9塞进迷你主机，再用它来做All In One？这也太超前了吧**

● <font color="#FF8C00">积核IT13迷你主机：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQoJK1olXwQAVFZeD08WBF8IGloUWwAEXVxUDkMnRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWBWkOElkcWw4dDRsBVXt8UGtKQxtKGWRBMl8hdzRTZBEAH11lUQoyVW5eCUkXCm4MH14dbTYCU24LZksWAm4NHloQXAQyVW5dDkoQAGoMGV4QWgALZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXM2w4G1oVVQUCVVdbCE4LA2oAH1MRQQYEVVleDU8VBm8OH1glXwcDUFdtOHtscTd3WQkUBgdEMV4udxF1RypKUBMQFH9sViUnagJhY2ZuGglQKEN-PyAPOA)



<HR>

**<font color="#ed25ff">EP151- 莫 老 师 的 10 万 粉 抽 奖 !</font>**

● 以下为获奖名单

○ 恭喜B站小伙伴 <font color="#DB7093">@行_至</font> 获得零刻SEi12迷你主机

○ 恭喜B站小伙伴 <font color="#DB7093">@晨微凉啊</font> 获得蜗牛星际j1900 NAS

○ 恭喜B站小伙伴 <font color="#DB7093">@霜顷</font> 小米平板2 8+128G 魔改版

○ 恭喜B站小伙伴 <font color="#DB7093">@天选来一个</font> 蒲公英X1组网盒子

○ 恭喜B站小伙伴 <font color="#DB7093">@Scorpionn</font> 玩客云

○ 恭喜B站小伙伴 <font color="#DB7093">@C--2020</font> 升腾C92

○ 恭喜B站小伙伴 <font color="#DB7093">@水之鱼幸福</font> H28K软路由

○ 恭喜B站小伙伴 <font color="#DB7093">@把爱烧成落叶q</font> 歌华链路由

○ 恭喜B站小伙伴 <font color="#DB7093">@大莽夫能屈能伸</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@零碎の기억</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@左-岚</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@智巧达</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@Giant_GKL</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@知了不知春秋</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@MarshalCrE</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@唐浚凯</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@赤殇之夕</font> Ventoy U盘 莫老师定制版

○ 恭喜B站小伙伴 <font color="#DB7093">@月球蜂鸟哭泣</font> Ventoy U盘 莫老师定制版

● 以下为抽奖规则

*中奖通知已通过B站私信发送，请尽快填写收货信息，我将为您邮寄奖品*



<HR>

##### **EP150 - 双系统切换！给Switch刷入大气层及Android11系统，并Root**

● Switch大气层+特斯拉整合包（1.6.2）：https://pan.quark.cn/s/c50462ce0744

● Switchroot（官网）：https://switchroot.org

● Switch安卓固件：https://pan.quark.cn/s/c3e46138d8aa （双层压缩包会失效，我把固件解压出来上传了，下载完成直接复制进Switch即可，无需再解压）

● Switch用面具：https://pan.quark.cn/s/adaaa9a802e1

● Android ADB工具：https://pan.quark.cn/s/cb97b388edc6



○ 以下为需要敲的代码，每个代码块为一条，按一次回车（Windows CMD报错，在命令前加.\）：

#删除现有（默认）NTP服务器：

```
adb shell settings delete global ntp_server
```

#设置新的NTP服务器：

```
adb shell settings put global ntp_server time.asia.apple.com
```



○ 以下为在本期视频中未提到的补充说明，写在这里是为了防止视频被和谐：

```
搭载哪些芯片的Switch可以刷入第三方系统？

Switch并非所有机器都能刷入安卓系统，这和机器中安装的破解芯片有关，例如TX芯片就无法安装第三方系统，体现为在刷入REC时，机器会直接重启至hekate界面，无法进行下一步，现阶段，市面上主流的Switch破解芯片有TX（一般为早期发售的机器搭载），国产芯片（就是高仿TX），以及树莓派（最新的），所有型号的TX芯片，均不支持刷入第三方系统，国产芯片则分不同情况，低版本芯片固件（0.3.1以下）的不支持刷入第三方系统，高版本芯片固件（0.7.2以上）的支持刷入第三方系统，所有国产芯片均支持升级芯片固件，装不了第三方系统需要自己手动升级芯片固件到高版本，最后是树莓派，树莓派全部支持刷入第三方系统

如何判断自己的破解芯片版本？

①麻烦但准确的办法：拆机，直接看芯片
②简单但不一定准的办法：Switch关机拔内存卡，再开机，显示一张内存卡和问号为TX芯片，显示小火箭NOSD为国产芯片，显示一颗树莓NOSD为树莓派芯片，直接进入了正版系统，可能为国产芯片或树莓派

```



<HR>

##### **EP149 - PS Portal ×，Switch串流 ✓，NS串流PS5指南**

● Chiaki（官网）：https://sr.ht/~thestr4ng3r/chiaki

● Chiaki（nro+nsp前端）：https://pan.quark.cn/s/7a14d3391138

● 在线获取PSN Account ID：https://psn.flipscreen.games



<HR>

##### **EP148 - 超超超大屏玩游戏！戴上雷鸟Air2，我的思维驰终于不用吃灰了**

● <font color="#FF8C00">雷鸟Air2 AR眼镜：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARIJK1olXwYEUV5YDkMSAl8IGloUWwcGUFhaAUsnRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWBW4MH10SVAYdDRsBVXtKSxh3Gi5dPGZCMggmUQB-XQZVTxtDUQoyVW5eCUkXCm4MH14dbTYCU24fZpO9hbeBtYKjxt-jwInikZ-fjV8JK1sTXAMEVV9eC0kRBmw4HFscbUBWCxsFWBRRVzBmR2slbQUyU15UHE1lQj0cHSklbQYyV25dCUseCm8IE1McXBoCVVleAU4LA2kJHl0UXAUDUllbC3sVAm4MEmslbVFAPSEuTSNVazl3bjpNI25rD14qe0xpcAEKXwNtWF5pKgA1axBLWW8IfDIl)



<HR>

##### **EP147 - 所有机型通用！通过Termux_Qemu，给手机安装Windows**

● Qemu用Win10镜像（来自bilibili@千寻roblox）：https://pan.quark.cn/s/5c8f59d84e74 （提取码：xhvV）

● Qemu用Win7镜像：https://pan.quark.cn/s/ce2b8ad4c17f （提取码：8HNk）

● Qemu用WinXP镜像：https://pan.quark.cn/s/027514f4c97b (提取码：2Nn7)



<HR>

##### **EP146 - 生产力提升了多少？零刻SEI12 i7-12650H办公软件性能实测**

● <font color="#FF8C00">零刻SEI12 i7-12650H迷你主机：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwUDUlhYDUkXBF8IGlodXwMBXFZcCEsVAl9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmcKHlgdVQcCVFxcFxJSXzI4RhJ3HAAAFy44WgNHVHVPRhkXXGBnJFJROEonAG4KG1IUWQIHXG5tCEwnQgEIGF0XWQQHUW5cOEsRAmoJGlMRWAAGU1xtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYKV15eCkwTA3MIGV4UWAIeVFhcDUoWC2sKE18VXzYAVV9ZAXsnMzVbYV5UX1JlACoEck1QQAp_Gzx0BkVADzBfAU9wWDYIGl9BInJfKVhfahYn)



<HR>

##### **EP145 - 坏了，这回手机真变电脑了！给手机安装Linux系统，变身生产力神器**

● Termux（官网）：https://termux.dev/en

● Termux：https://pan.quark.cn/s/8de40d0dd427 (提取码：J28i)

● VNC Viewer（官网）：https://www.realvnc.com/en/connect/download/viewer

● VNC Viewer：https://pan.quark.cn/s/d0232c9e915f (提取码：d9sX)



○ 以下为需要敲的代码，每个代码块为一条，按一次回车：

#更新Termux：

```
pkg upgrade
```

#启动TMOE一键脚本：

```
bash -c "$(curl -L l.tmoe.me)"
```

#启动VNC服务：

```
startvnc
```

#进入Ubuntu（或你安装的其他）系统：

```
debian
```

#进入TMOE脚本：

```
tmoe
```

#使Termux在Android12以上系统后台常驻（直接复制可能导致代码格式变化，建议复制后手动再编辑下格式）：

```
apt update
apt upgrade -y
apt install git -y
git clone https://github.com/SaicharanKandukuri/termux-android12-phantom-fix
cd termux-android12-phantom-fix
bash runme.sh
```



<HR>

##### **EP144 - 用8Gen3玩模拟器游戏怎么样？聊聊现阶段的模拟器兼容性**

● PPSSPP模拟器（官网）：https://www.ppsspp.org

● PPSSPP模拟器：https://pan.quark.cn/s/2d94999cf0d9 （提取码：njUf）

● AetherSX2模拟器（官网）：https://www.aethersx2.com/archive

● AetherSX2模拟器：https://pan.quark.cn/s/beccef7ff8fd （提取码：rexs）

● AetherSX2模拟器（BIOS）：https://pan.quark.cn/s/3e588b5c8ef7 （提取码：pFhk）

● Citra MMJ：https://pan.quark.cn/s/727908111af7 （提取码：y57k）

● Dolphin MMJR2.0最后一个版本：https://pan.quark.cn/s/25a8d5d4853b （提取码：6pmL）

● YUZU模拟器（官网）：https://yuzu-emu.org

● YUZU模拟器：https://pan.quark.cn/s/eb6ba52e6f39 （提取码：aUhP）

● 高通骁龙8Gen2萝卜驱动：https://pan.quark.cn/s/891c8ad48347 （提取码：rkNy）

● 高通骁龙8Gen2萝卜驱动（测试版）：https://pan.quark.cn/s/0135d6371bcd （提取码：MVw3）

● 蛋蛋模拟器（官网）：https://eggnsemulator.com

● Vita3K模拟器（官网）：https://vita3k.org

● Vita3K模拟器：https://pan.quark.cn/s/60341339b463 （提取码：fMVL）

● Vita3K模拟器（固件）：https://pan.quark.cn/s/3591b3d86afa （提取码：4FCA）

● Vita3K模拟器（字体）：https://pan.quark.cn/s/d41aab048fbf （提取码：rE8Q）

● Limbo模拟器增强汉化版：https://pan.quark.cn/s/bfefde6842b7 （提取码：an47）

● Tiny Win7精简版系统：https://pan.quark.cn/s/7ce032077845 （提取码：dqx9）

● Exagear增强汉化版：https://pan.quark.cn/s/5e7419c85b57 （提取码：XaZ4）

● Winlator直装版：https://pan.quark.cn/s/233044b4c5b9 （提取码：aMBG）

● InputBridge虚拟键盘：https://pan.quark.cn/s/4dc32edf9cda （提取码：7EiL）

● 红警2共和国之辉手机直装版：https://pan.quark.cn/s/2ae303421d3d （提取码：uh78）

● 红警2尤里的复仇手机直装版：https://pan.quark.cn/s/578420174def (提取码：g1Ja)

<HR>

##### **EP143 - 我们需要什么样的磁盘阵列柜？铁威马D2-320、绿联CM335对比评测**

● <font color="#FF8C00">铁威马D2-320磁盘阵列柜：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAbAJK1olXwQAVF5fCUgSB18IGlocWgMGVlhUCEgeAV9MRANLAjZbERscSkAJHTRQRA1CCVkdDwtCWhVLHTdNTwcKBENeCVAfUg8bA24JElwQWQQEXV5eAUkAQ2N8YitwJHV9FCkkdC9ucAxKbTJpBWJmJBgqUBZgYSZ4XTtgLWVlDS4UawMXdQ1BcxtiP1xnNhc5Tj9-czxxaBJCKX9-NicuYwxgejVuYDxpW2NKNyg6VxV_UQl0fjhcXUV2CyYOaDh8RBhqczJiB1NDNFw-cTxOZCx8ciBjKV9yXSokazxjcQxXbTJpOnJhAR8qcR1PMyd_HF5dAGYANC0FcC1CGRlQRAtUJ2YOWG5cOEgWAW8BGl8RWA4yZF5aOAp5A28OH14SXAUyVW5dDkoSAm4AElkWWg8EZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXAF8LK1sUXQ8KUFhdD0IVH28MGF0cWRoCUl9YCUofCmwPG1kdbQQDVVpUOHsnfxx9XQlvPXZiJzkoDwlcAjBPeyxVVU96OlwgYyt1ASpSHTtWAAdqDQMGens)



<HR>

##### **EP142 - 红米十周年，从一个极客的角度聊聊K70 Pro**

● <font color="#FF8C00">红米Redmi K70Pro：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwQHU1lZCUoVAl8IGloUWwEEUl9YCk0nRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWBWgOHVoQXwAdDRsBVXt3awcSU1p2GWR9UyNdQTVyQC1jXSFDUQoyVW5eCUkXCm4MH14dbTYCU24fZglVRjBSQBNcC0QFU25cOEsRAmoJGlMdVQcFV15tD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLUl1UD0wVCnMIGFIQWA8eVFhcDUoWC2cOG1gQXjYAVV9ZAXsnMwwJQT9MGFxeDixaUiBwfgxjYiFGCFVLXTBfdiptUx1uEyBPCn9jXAoZDxcn)



<HR>

##### **EP141 - 更小，更快，更稳定，Windows X-Lite精简系统安装使用**

● Windows X-Lite（官网）：https://windowsxlite.com

● Windows X-Lite Win10 22H2 (Optimum)：https://pan.quark.cn/s/23b52e9c4c70 （提取码：xmHt）

● Windows X-Lite Win11 23H2 (Optimum)：https://pan.quark.cn/s/4c5925cc364d （提取码：JRTz）

● Windows X-Lite Win11 23H2 (Micro)：https://pan.quark.cn/s/40565e6bc7c3 （提取码：emAy）



<HR>

##### **EP140 - 思 维 驰 刷 机 记 ！**<font color="ff1616">（被B站限流了）</font>

<font color="207ac5">● 本期视频虽然只是一期吐槽向视频，也并未展示完整刷机流程与芯片焊接相关画面，但还是被B站噶了，所以，可能就没有后续了..</font>

<font color="ff66ae">● 视频源链接在此，你可以点这里围观：</font>https://www.bilibili.com/video/BV1PC4y1N7FE （和谐版）

<font color="ff66ae">● 原版，西瓜视频：</font>https://www.ixigua.com/7306024789477589567 （未和谐原版）

<HR>

##### **EP139 - 有手就行！3分钟，让你在安卓手机上玩红警**

● 红警2共和国之辉手机直装版：https://pan.quark.cn/s/2ae303421d3d （提取码：uh78）

● 红警2尤里的复仇手机直装版：https://pan.quark.cn/s/578420174def (提取码：g1Ja)

● 红警2尤里的复仇PC绿色版：https://pan.quark.cn/s/d4e44373f68c (提取码：bjR2)



<HR>

##### **EP138 - 所有版本通用！保留现有数据，Switch大气层及系统离线升级指南**


● 大气层+特斯拉整合包（最新）：https://pan.baidu.com/s/1Aq53TNTUTccNkQRAcg_Y3Q?pwd=xlcj

● 大气层+特斯拉整合包（1.6.2）：https://pan.quark.cn/s/861c576ff095 (提取码：W9as）

● Switch离线固件（最新）：https://darthsternie.net/switch-firmwares

● Switch离线固件（17.0.0）：https://pan.quark.cn/s/c3c37b6e8701 (提取码：CSxC)



<HR>

##### **EP137 - 更简单、更易用的多系统引导工具，Grub2Win使用指南**

● GRUB2WIN（官方下载）：https://sourceforge.net/projects/grub2win/files

● GRUB2WIN：https://pan.quark.cn/s/3fba9e118b2e (提取码：jNpY)



<HR>

##### **EP136 - 我将以摸鱼形态舒适躺平？对比同价位产品，聊聊Ergoup有谱E20人体工学椅**

● <font color="#FF8C00">Ergoup有谱E20人体工学椅：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQoJK1olXwYFXFtVDEgQCl8IGlocVQUAU1lVC08VBF9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmYAGFkSWg4BUFxaFxJSXzI4fyR0KQNmCyY9CRdeVwdaf1ltGEBfAlJROEonAG4KG1IUWQIHXG5tCEwnQgEOGVwdXAUyVW5dDkoSAm8JGl4cWwcCZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXM2w4G1oVVQUHU1xbDkkLA2wBE10XQQYEVVtcCEoWBmwBElklXwcDUFdtOHtUSw1AZlhKFVlZCDwPajZICxV9UF1CWn9sVgAcfQhSYGhBRDlTL1N9HSg7OA)



<HR>

##### **EP135 - 多系统、镜像引导神器，Grub4Dos For UEFI使用指南**

● GRUB4DOS For UEFI（官方下载）：http://grub4dos.chenall.net

● GRUB4DOS For UEFI：https://pan.quark.cn/s/7a39668493ec (提取码：rmX9)

● GRUB4DOS For UEFI主题：https://pan.quark.cn/s/3458f295ae5d (提取码：cmjp)

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

● EasyUEFI：https://pan.quark.cn/s/aa6412345b7a （提取码：4K8a）

● 莫老师编辑过的menu.lst文件：https://pan.quark.cn/s/664776a9feb5 (提取码：9sXW)



<HR>

##### **EP134 - 明基主打性价比的4K投影仪？聊聊GK100的使用体验**

● <font color="#FF8C00">明基GK100 4K投影仪：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARMJK1olXwMBUFpaCk8VBF8IGloUXgIGUV1bC0InRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWAGsMHlgTXg8dDRsBVXtwAB9jYR9sH2NFTi1ae0xeZRVMGwJDUQoyVW5eCUkXCm4MH14dbTYCU24fZhhDXC_fsuTB843V7_qJhMvAruQ4GmsVWwcHVV5cCU0fCmcAK1wVVDZEAAEYUBtIRTtXdQclbTYBZFldAV8RcS5aD11nbTYCZF1tCEoXCmkKHl0XVAEeVFpfC0oVH28OGl4UXQcDUlhdCUonAW4JH1IlbTZ8MBo7YzF-ZgZ-Wx9JJnVHVyA7aExJdxNmGThwO1kBEFcNYQ9pQw9LWQRwbQ)



<HR>

##### **EP133 - 利用MSMG Toolkit，精简一个独属于自己的Windows系统**

● MSMG Toolkit 13.6中文版：https://pan.quark.cn/s/a4a50c4a0842 (提取码：TVyr)

● MSMG Toolkit 组合包（适用于集成功能，精简系统不需要这个）：https://pan.quark.cn/s/664776a9feb5 (提取码：9sXW)

● Windows原版镜像下载：https://hellowindows.cn



<HR>

##### **EP132 - 才不是VR、AR眼镜呢！画质即正义的观影头显，GOOVIS G3 MAX上手**

● <font color="#FF8C00">GOOVIS G3 MAX头戴显示器：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAREJK1olXwMCUlpVCUoRBV8IGloUWAQEXV1fDEsnRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWBm0OElgXWQYdDRsBVXtzAQcNYSdKXGNEKhYZSSNKdxVtazxTUQoyVW5eCUkXCm4MH14dbTYCU24fZhRC29uOzfebhJC1AgADTxNVM244G10UWAcCVV5YCksTBF8PG1IlG1JdEQYNVw1DXAFUK2slXjYFVFdJDjlWUXsOaWslXTYBZF5cCEMUBmgMGVoQQQYDVVZUC1cXBW4NGlsUXQQGUF9eOEkWAmsBK2slJ29WDzgtDSkSRBlcSDJqOGZJFSFcURBMbW1yZhpmIgBdUFsUQzsSYGkKbms)



<HR>



##### **EP131 - 真有人背17.3寸的游戏本上下班？Nazoroad Tramp双肩背包上手体验**

● <font color="#FF8C00">Nazoroad Tramp双肩背包：</font>[点此查看](https://m.tb.cn/h.5SGvLKK)



<HR>


##### **EP130 - 时代的眼泪！给歌华链路由刷入Breed不死及第三方固件**

● 1.21降级固件：https://pan.quark.cn/s/9e37ca0b71d2 (提取码：QNiz)

● Breed不死固件：https://pan.quark.cn/s/7ce1d7d22d33 (提取码：ZCXy)

● Lede第三方固件：https://pan.quark.cn/s/103cd0f8dce0 (提取码：Cte5)

● tftpd64：https://pan.quark.cn/s/33a2b1228584 (提取码：GsT7)

● hfs：https://pan.quark.cn/s/103cd0f8dce0 （提取码：Cte5）

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html



<HR>

##### **EP129 - 一键重装的版本答案？利用Ventoy+应答脚本，手搓一个无人值守系统安装U盘**

● Ventoy（官网）：https://www.ventoy.net/cn

● Windows原版镜像下载：https://hellowindows.cn

● Ventoy用Windows系统安装脚本：https://pan.quark.cn/s/371d081d1cf8 (提取码：YMqm)



<HR>

##### **EP128 - 我的启动U盘有亿点点不一样，Ventoy进阶使用指南**

● Ventoy（官网）：https://www.ventoy.net/cn

● Ventoy引导Linux用数据持久化dat文件：https://pan.quark.cn/s/8bb9b686356a (提取码：dAU9)

● Ventoy用Windows系统安装脚本：https://pan.quark.cn/s/371d081d1cf8 (提取码：YMqm)



<HR>

##### **EP127 - 【抽奖】一年一度的抽大米环节！**

● <font color="#DB7093">本活动仅在bilibili进行</font>，请进入我的[B站主页](https://space.bilibili.com/1995424953/dynamic)，或点此查看[置顶动态](https://www.bilibili.com/opus/847340998199607313?spm_id_from=333.999.0.0)

● 本次抽奖已结束，共计抽出10个礼品

● 以下为获奖名单：Soul丶柒；進撃のアラン；改个啥子名字；被仰望的男人；聪明睿智嘤嘤怪；woohoo欧；HAC鲨鱼霖霖；MarshalCrE；我不是小晟啊；南方的样子



<HR>

##### **EP126 - 一台0.1L的软路由能做什么？H28K小白入坑指南**

● 瑞芯微开发工具：https://pan.quark.cn/s/10cba052a881

● H28K OpenWRT固件：https://pan.quark.cn/s/ea64345809fd (提取码：cwyZ)

● H28K Ubuntu固件：https://pan.quark.cn/s/dfadd7333b61 (提取码：1cHf)

● H28K iStoreOS固件：https://fw.koolcenter.com/iStoreOS/h28k/

● BalenaEtcher（官网）：https://www.balena.io/etcher

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html

● *设置Smaba密码的代码（在MobaXterm里输入）*

```
smbpasswd -a root
```



<HR>

##### **EP125 - Batocera+Ventoy，打造一个多合一终极模拟器游戏U盘**

● Batocera（官网）：https://batocera.org

● Batocera基础整合包by_溅の小孩：https://pan.quark.cn/s/0c9465a59127 (提取码：GKbh)

● Batocera 64GB整合包by_溅の小孩：https://pan.quark.cn/s/f3f24dc476d9 (提取码：S56a)

● Ventoy（官网）：https://www.ventoy.net/cn

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

● BalenaEtcher（官网）：https://www.balena.io/etcher



<HR>

##### **EP124 - 核显能玩3A游戏吗？零刻SER7 7840HS迷你主机游戏体验**

● <font color="#FF8C00">零刻SER7 7840HS迷你主机：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwUDUlhYDUkXBF8IGloTWgMGXV5aDUIfAF9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmkPHl8cXQEHXVZeFxJSXzI4bDhtP350CAE_dhdqBSR3WTpVPlFCJFJROEonAG4KG1IUWQIHXG5tCEwnQgEIGF0XWQQHUW5cOEsRAmoJG1oWXA4KUVxtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYKVl9fC0kQAnMIHl0SWQIeVFhcDUoXAmwJEloTWDYAVV9ZAXsnMxRqSBNnI3wKPAFYWyxSdR1ceQxiC3ADDTAPcDVAVRZ2ejlvA2ICCgoWYRMn)



<HR>

##### **EP123 - 旧电脑变NAS，超简单的黑群晖DSM7.2安装指南**

● FirePE（官网）：https://firpe.cn/page-247

● DSM7.21引导（来自@GXNAS）：https://pan.quark.cn/s/f29ca7a66bc2

● GXNAS博客：https://wp.gxnas.com/11849.html

● DSM7.21官方固件：https://pan.quark.cn/s/d90407800171

○ wjz304大佬已将ARPL项目转为私有，引导已经用不了了，用上边GXNAS大佬的吧

● ARPL引导镜像，来自wjz304（Github）：<del>https://github.com/wjz304/arpl-zh_CN/releases</del>

● ARPL引导镜像，来自wjz304：<del>https://pan.quark.cn/s/edcb2b87f3d0 (提取码：bArc)</del>



<HR>

##### **EP122 - 多种机型适用，给小米路由器恢复官方原版系统，也适用于救砖**

● 小米路由器修复工具：https://pan.quark.cn/s/2b06ef93db6f （提取码：SVB5）

● AX6S开发版固件1.2.7：https://pan.quark.cn/s/0c795a87a5f4 （提取码：H5mR）



○ ***如何给AX6s安装ShellClash？***

登录小米路由器后台，点击常用设置，系统状态，选择手动升级，弹出的框框点选择文件，这里要选1.2.7（内测版固件），这个固件自带SSH权限，点击开始升级，稍等片刻，wifi重连，路由器便降级成内测固件了，接着查看你路由器屁股下边的SN码，记住它，打开ROOT密码计算网站，输入你SN码，计算出ROOT密码，打开MobaXterm，左上角Session，弹出的框框选Telnet，Remote host填路由器后台ip地址，Username填root，点击ok，显示XiaoQiang login：输入root，Password输入你刚刚算出的SN密码，回车，出现一个大大的ARE U OK，接着把下边三排代码依次右键粘贴进去回车执行

```
nvram set ssh_en=1& nvram set uart_en=1 & nvram set boot_wait=on & nvram setbootdelay=3 & nvram set flag_try_sys1_failed=0 & nvram setflag_try_sys2_failed=1
```

```
nvram setflag_boot_rootfs=0 & nvram set "boot_fw1=run boot_rd_img;bootm"
```

```
nvram setflag_boot_success=1 & nvram commit & /etc/init.d/dropbear enable &/etc/init.d/dropbear start
```

每粘贴一条就按一次回车，直到三条代码都执行完成，接着我们点左上角Exit退出Telnet窗口，再次打开MobaXterm，点击Session，这次弹出的框框要选SSH，Remote host填路由器后台ip地址，Username填root，点击ok，跳出的框框选Accept the new server hostkey and carry on connecting，进入后输入root密码，接着粘贴下边这排代码回车

```
export url='https://raw.fastgit.org/juewuy/ShellClash/master' && sh -c "$(curl -kfsSl $url/install.sh)" && source /etc/profile &> /dev/null
```

就可以开始安装ShellClash了，问你想要安装的版本，选1公测版，问要装到哪儿，选1/data目录，让你确认一下，输入1回车，然后开始跑进度条，跑完就装完了，接着输入clash就可以开始配置了，让你选择使用环境，选1路由设备配置局域网透明代理，问你是否启用软固化，输入1回车，请输入需要还原的SSH密码，回车跳过，导入配置文件，输入1开始导入，输入1在线生成Clash配置文件，接着粘贴你的机场订阅链接回车，输入1开始生成配置，配置成功后输入1，立即启动clash服务，然后你就可以愉快的使用ShellClash了，当然此刻也可能出现核心下载失败的问题，你可以选择9更新/卸载，7切换安装源/安装版本，尝试切换源，你还可以按9更新/卸载，选择4安装本地Dashboard面板，3安装Yacd面板（4魔改版也可以），1data目录安装，接着在浏览器输入192.168.31.1:9999/ui回车，就能开始愉快的使用了，enjoy！



● 小米路由器ROOT密码计算网站：https://blog.isteed.cc/post/miwifi-sshpwd

● 小米路由器ROOT密码计算网站（本地离线版）：https://pan.quark.cn/s/c2fd132315aa (提取码：uRXQ)

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html



<HR>

##### **EP121 - 游戏玩家的巨幕形态，明基X3000专业游戏投影仪上手体验**

● <font color="#FF8C00">明基X3000专业游戏投影仪：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARMJK1olXwMBUFpaCk8VBF8IGloUXw4GVFhfAEknRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWAWcMG10XVQQdDRsBVXsQVG8NXitUImQHFC0hbCxLWwkOGA5TUQoyVW5eCUkXCm4MH14dbTYCU24fZhhDXC_fsuTB843V7_qJhMvAruQ4GmsVWwcHVV5cC04eAWgLK1wVVDZEAAEYUBtIRTtXdQclbTYBZFldAV8RcS5aD11nbTYCZF1tCEoXC2wIGF4WXwUeVF1fDkoQH28OGl4UXQcBUVtZC0onAW4JH1IlbTZdVgE4ADdVBy1NRgReIV5UMFkWbDVSXBBmGRBcFlx7BFgKSj0QRC9dZwx8bQ)



<HR>

##### **EP120 - 更稳定方便的精简游戏系统，ReviOS部署汉化指南**

● ReviOS（官网）：https://revi.cc/

● ReviOS 10镜像：https://pan.quark.cn/s/189e0ff0efab (提取码：JdAK)

● ReviOS 11镜像：https://pan.quark.cn/s/e1b292babce9 (提取码：USs5)

● EasyRC官网：https://firpe.cn/page-196

● EasyRC：https://pan.quark.cn/s/6c2523d2ad26 （提取码：dQ8v）

● FirePE（官网）：https://firpe.cn/page-247



<HR>


##### **EP119 - 5.3K 10Bit HDR 4K120FPS 加持，GoPro12运动相机上手实拍体验**

● <font color="#FF8C00">GoPro Hero12 Black：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQoJK1olXwQAVV9eDk8RAl8IGloUWgUFVltZDEInRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWBGwPGV4RWQ8dDRsBVXsWCzd6XB8WCmN0FChddSpwHTNqQSxlUQoyVW5eCUkXCm4MH14dbTYCU24LZksWAm4JGlodXgIyVW5dDkoSAm8JGFITXA4CZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXM2w4G1oVVA4GUl5YDksLA24KGl0VQQYEVVtcCEoUBWsLE1MlXwcDUFdtOHtRWxlxRicVOQZWISguCkt0f2wBaAxVIHBsVg4fATJRARluGyMWWWRKAD9cOA)



<HR>

##### **EP118 - HotPE作者全新装机工具，SysRi一键重装体验评测**

● SysRi（官网）：https://sysri.cn

● SysRi（文档）：https://docs.sysri.cn

● EasyRC官网：https://firpe.cn/page-196

● EasyRC：https://pan.quark.cn/s/6c2523d2ad26 （提取码：dQ8v）

<HR>

##### **EP117 - 在手机上玩王国之泪？一加Ace2 Pro模拟器游戏实测体验**

● PPSSPP（PSP模拟器）：https://www.ppsspp.org

● Cirta（3DS模拟器）：https://citra-emu.org/download

● Dolphin（Wii模拟器）：https://cn.dolphin-emu.org/download

● AetherSX2（PS2模拟器）：https://www.aethersx2.com/archive

● AetherSX2（模拟器）BIOS合集：https://pan.quark.cn/s/1e3f5d3264d8 （提取码：qTqs）

● YUZU（SWITCH模拟器）：https://yuzu-emu.org/downloads/#android

● YUZU（骁龙8Gen2 GPU驱动）：https://pan.quark.cn/s/4c7ea0d3d135 （提取码：hvYf）



<HR>

##### **EP116 - 你的下一台蓝光播放器，也许是NAS？聊聊极空间Z2Pro的影音功能**

● <font color="#FF8C00">极空间Z2PRO个人私有云：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQcJK1olXwQAVVhVCEoUBV8IGloUWQ8EUlldDU0nRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWB2YOHVwVWAAdDRsBVXtnSg9VRS1PI2YGUxsndTlFfxNJUjNTUQoyVW5eCUkXCm4MH14dbTYCU24fZg5CSmYBHFwlXDYCUl9YCUsWBmsLG1oQbQECXW4bXBRSWz9XXQ9KM1oyZG5eOEwXCnsOaRpHSQBwZG5dOEgnA24IElIcXwYFVV5BCEgWAW4PB1sTXAMDVF9YDU0XCmw4GVoUWQ8yZG5aVDhLShtQYwNrHnV6VAk8XSlMYB1hZgd7X09QDwwLQ0hHWxVqfFt9O3oAZA)



<HR>

##### **EP115 - 2种方法远程重装系统，拯救异地女友被流氓软件“纠缠”的电脑！**

● ToDesk（官网）：https://www.todesk.comf

● EasyRC官网：https://firpe.cn/page-196

● EasyRC：https://pan.quark.cn/s/6c2523d2ad26 （提取码：dQ8v）

● 软碟通：https://pan.quark.cn/s/2b551c9010ab (提取码：ENNc)

● 雷电PE win10内核：https://pan.quark.cn/s/def33a8d337e （提取码：46uV）

● 雷电PE win11内核：https://pan.quark.cn/s/62b855fedc2d (提取码：vVWC)



<HR>

##### **EP114 - 超简单制作WTG、系统U盘，小巧精悍的写盘软件，Rufus使用指南**

● Rufus（官网）：https://rufus.ie/



<HR>

##### **EP113 - 帧数暴涨？低配救星？AtlasOS安装部署指南及性能测试**

● AtalsOS（官网）：https://atlasos.net/

● EasyRC官网：https://firpe.cn/page-196

● EasyRC：https://pan.quark.cn/s/6c2523d2ad26 （提取码：dQ8v）

● Win10 22H2（微软官方节点）：*请使用迅雷等第三方下载软件进行下载*

```
ed2k://|file|zh-cn_windows_10_business_editions_version_22h2_updated_april_2023_x64_dvd_c03ed5aa.iso|5971707904|EED818987B8BC17F6DDC201E977A4F95|/
```

```
magnet:?xt=urn:btih:84a9c3c817073e64b2ece7a9a6d6ea47782cdc88&dn=zh-cn_windows_10_business_editions_version_22h2_updated_april_2023_x64_dvd_c03ed5aa.iso
```

<HR>

##### **EP112 - 死去的回忆涌上心头，使用EKA2L1模拟器，在安卓系统上模拟运行诺基亚塞班Symbian游戏**

● EKA2L1：https://pan.quark.cn/s/33681cb7bdd0 （提取码：c7CU）

● EKA2L1（Github）：https://github.com/EKA2L1/EKA2L1/releases

● 诺基亚手机固件（天翼云盘）：https://cloud.189.cn/web/share?code=7RvY3yNbUfUj （访问码：7hi7）

● 诺基亚手机固件：https://pan.quark.cn/s/545a49040b01

● 诺基亚塞班平台游戏（视频中出现的几款）：https://pan.quark.cn/s/84080b9147be （提取码：hT1F）

● 诺基亚塞班平台游戏：https://pan.quark.cn/s/47857d476c55 （提取码：UkwS）


<HR>

##### **EP111 -2G内存流畅运行？5款精简修改版Windows系统，纯净、好用**

● 不忘初心（博客）：https://www.pc528.net

● WinOS（博客）:https://www.winos.me

● 吻妻Win7（官网）：https://www.newxitong.com

● 吻妻Win10（官网）：https://iwin10.net/2023/0405.html

● AtlasOS（官网）：https://atlasos.net

● Tiny10：https://pan.quark.cn/s/410bd9410681 （提取码：5V8v）

● Tiny10（国外网盘，很慢）：https://archive.org/download/tiny-10_202301

● Tiny11（国外网盘，很慢）：https://archive.org/details/tiny-11_202302



<HR>

##### **EP110 - 第三方ROM更香？给小米平板2刷入LineageOS、RROS、RemixOS，支持双系统**

● 小米平板2专用PE+LineageOS+RROS+RemixOS固件+Windows固件：https://pan.quark.cn/s/59225037ac56 (提取码：PnAP)

● 小米平板2专用PE+LineageOS+RROS+RemixOS固件+Windows固件（天翼云盘）：https://cloud.189.cn/t/7ZvaQrYF7ja2 （访问码: 5ucr）

● 小米平板2专用PE+LineageOS+RROS+RemixOS固件+Windows固件（百度云）：https://pan.baidu.com/s/1l0RUPwaUifhfiPXjVfDAuQ （提取码：gkxc）

● 亚马逊的蝴蝶小米平板2刷机教程：[点此访问](https://mp.weixin.qq.com/s?__biz=MzI2MDA4OTY0Mw==&mid=2247489032&idx=1&sn=65351fb7887decd233573ce6faf1e768&chksm=ea6fa44cdd182d5a5f05e9bd35de5a90b4aa9063ed7021c3bdf8062dddea316ede7225bc88fb&scene=21#wechat_redirect)

● 亚马逊的蝴蝶小米平板2刷机疑难解答：[点此访问](https://mp.weixin.qq.com/s/q8L4YrGlhiaEkqmqG_oD7Q)

<HR>

##### **EP109 - 2023年了，小米平板2还香吗？魔改版小米平板2双系统刷机指南**

● 小米平板2专用PE+miui固件+Windows固件（天翼云盘）：https://cloud.189.cn/t/7ZvaQrYF7ja2 （访问码: 5ucr）

● 小米平板2专用PE+miui固件+Windows固件（百度云）：https://pan.baidu.com/s/1l0RUPwaUifhfiPXjVfDAuQ （提取码：gkxc）

● 亚马逊的蝴蝶小米平板2刷机教程：[点此访问](https://mp.weixin.qq.com/s?__biz=MzI2MDA4OTY0Mw==&mid=2247489032&idx=1&sn=65351fb7887decd233573ce6faf1e768&chksm=ea6fa44cdd182d5a5f05e9bd35de5a90b4aa9063ed7021c3bdf8062dddea316ede7225bc88fb&scene=21#wechat_redirect)

● 亚马逊的蝴蝶小米平板2刷机疑难解答：[点此访问](https://mp.weixin.qq.com/s/q8L4YrGlhiaEkqmqG_oD7Q)

● EasyUEFI：https://pan.quark.cn/s/aa6412345b7a （提取码：4K8a）

<HR>

##### **EP108 - 莫老师的工作室是什么样的？带你看看我每天剪片子的地方**

● 网易云音乐人主页：https://music.163.com/#/artist?id=49436906

● <font color="#FF8C00">歌德利V1人体工学椅：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwQHUlZYC08RA18IGloSVAYHV15ZCUoXAF9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmgBG14WXQIDVV5eFxJSXzI4SyhFHAZFEVg4UQN_UzRcUyhuR0R5AlJROEonAG4KG1IUWQIHXG5tCEwnQgEIGF0XXwYDVW5cOEsRAmoJG1oRXAcAV15tD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYKV15eCkwSBnMIH1wQWQ4eVFhcDUoXAmoAGV4dXDYAVV9ZAXsnM21XfT8QDntLKToWbjBlCgpoGTpnHmR3ITBfWgx2YGYAaxtoH3wBDiscYw8n)

● <font color="#FF8C00">山进M1蓝牙音响：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQEJK1olXDYCVV9cC0sRAW4KHl4lGVlaCgFtUQ5SQi0DBUVNGFJeSwUIFxlJX3EIGloUXgYEVl9fDU4IWipURmsLO0VLPVchDykUBGdcWwFeLwEBVRs9BEcnAl8LGlkVVAcGUFtVOHsXBF9edVsUXAcDVV5aD0snAl8IHVoQXAYDUFxYAE4QM2gIEmtTCVlHDA4CTh9IbTM4K2sWbQECXUpbegpFF2l6K2sVbQUyVF9dAU8RCmgMG1IJXQYDXFpdFEsRAmoJG1oRXwULVVltCkoWB2Y4K2tQCXxBBFYDXxVFVRVOXD9UAQ4AL1gvSwB5ATZTGSZTKlJaCi5VDjATBj9qKw)

● <font color="#FF8C00">aoduke区块化集线器：</font>[点此查看](https://m.tb.cn/h.5aFtt2G)

● <font color="#FF8C00">DOBE PS5充电底座：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXgYAUVZUAUofCl8IGloQXQcCUltVDU4RAl9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmoIGlsTWA4HUVhcFxJSXzI4Qg0cCFJbUgI9exdHSxNOTAhVOWFLJFJROEonAG4KG1IUWQIHXG5tCEwnQgEIGlkSVQUDVG5cOEsRAmoJG1oSXgMGXVptD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLUlxVD0kUAHMIGVoVXgYeVFhcDUoXAmgJHVsSXDYAVV9ZAXsnMxZyTCYRGARrVhVfXz1QfzdybRNSHn13LzBfYTlfXjlfRSkXWl1FFB0qbDsn)

● <font color="#FF8C00">奥睿科RGB拓展坞：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQoJK1olXwMBU15fDk8XAF8IGloUWgQHVFdZDk8nRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWBG0NG1IRWwIdDRsBVXtyRQR3Qgx1WmVEVwJVbjBAXzZhbjh1UQoyVW5eCUkXCm4MH14dbTYCU24LZksWAm4JGloWWg8yVW5dDkoSAm8JHFMdVAUGZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXM2w4G1oVVQQDVl1dD0ILA2oOH1gQQQYEVVtcCEoQB2gOE1MlXwcDUFdtOHtXR2xqUglRPEJBMl0ebR1QVi5bTwN0AlJsVhwIWztkfjEIXz9UInt3VSUOOA)

● <font color="#FF8C00">明基ScreenBar Halo 屏幕挂灯：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwMDVF9fC00SA18IGloXWwELUV9UDk4SB19MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAm0OHFIQXA8EUVtZFxJSXzI4RQgXNnFjAAA-dQ9RRy9MHw0VXE5WNFJROEonAG4KG1IUWQIHXG5tCEwnQgEIG1IQWQQCV25cOEsRAmoJG1oTXw4HXV1tD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLUFdUAUkUBHMIH18TWQUeVFhcDUoXAmkLHFsQXDYAVV9ZAXsnMwwJQT9MGFxeDixaUiBsZDlMYiFGCQJ-LDBfdiptUx1uEyBPKVQGAiQqfxcn)

● <font color="#FF8C00">铁三角AT2035麦克风：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwUHU1lYC04TB18IGloWXQMBV1pUDE0WAF9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmwIHlgWWQ8GUl9eFxJSXzI4cwFzFVYDDx0-TxNyWRZRZFsSGANQNFJROEonAG4KG1IUWQIHXG5tCEwnQgEIGloSVQ8KVm5cOEsRAmoJG1oTWwEBUFhtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLXV5dAEMQC3MIG1IXXQceVFhcDUoXAmkOGlwcWzYAVV9ZAXsnMzdOfwZvOmNhMTwvbE9ldmZVSV4UDX5DUzBfXRwSZisJaD9wGH1xFF9bdRAn)

● <font color="#FF8C00">Focusrite福克斯特2i4声卡：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQQJK1olXQ8EUlpYAE0SBF8LGlMTWgIKUV5fCntTXDdWRGtMGENDFlVDFhNSVzMXQA4KD1heSl1cAE0QB2cNG1kXQl9HCANtaFVtBT8LcDhwPAEHKgoGdDsfdhVNTVcZbQcyV19fCEIWB2sNE2slXQEyFTBZAE8QCmY4GmsVWwcHVV5cAU4TAW8NK1wVVDZEAAEYUBtIRTtXdQclbTYBZFldAV8RcS5aD11nbTYCZF1tCEoXC2wNHl0VWAQeVF9fCk4QH28OGl4UXQcLVVtbDk4nAW4JH1IlbTZmKjgfXiJufBZ_Wj1wJE9YNjgAUD0RVDdmGVodAGZbHzwUcQtXfzB6XQtcbQ)

● <font color="#FF8C00">AKAI MPK MINI PLUS MK3 MIDI音乐控制器：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQoJK1olXQUBUV9cCU4TCl8IGloWWwIDUFldD00UC19MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmwOH1oRWgYFUl1VFxJSXzI4fxhJKlAHAwU9VxN3BQh7aVxDWG5kElJROEonAG4KG1IUWQIHXG5tCEwnQgEPGlMVVQYyVW5dDkoSAm8JE1oWXQQHZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXM2w4G1oVVA4GUlheDUoLA20BGV0RQQYEVVtcCEoeBWYJHlklXwcDUFdtOHtEWS1xawJMDV93HBwrfB8QBgdWRD9zWXpsVl1bVhcfSgtbQiF-AV4KDxdZOA)

● <font color="#FF8C00">Ulanzi优篮子手机微距镜头：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQYJK1olXwUHUVpfCUwSA18ME1kcXwQKV1hYAXtTXDdWRGtMGENDFlVDFhNSVzMXQA4KD1heSlpVCkIVAWcLHV4cQl9HCANtDSJoaD9pWh13J1JwUgo0ABJBdjdyXVcZbQcyV19fCEIWB2sNE2slXQEyFTBdCUoTAG0AEmsUbQYEVVtcCEofAWwJHFMlWgYLZBgJVw5PUzBOTwR7ATYyZF1tD0seF2l6WgkBW3QyZF5tC3sXAm8BE18QWwEGUUJdDE4WCmwUG10UWAcCVVZeAU8XAF8KGloRVDYyZBsJcghHCzFfRQlDJ0ACECpYAElsZj12fzUXBF0AKRgqXBNJc2d9RT1GAGQy)

● <font color="#FF8C00">Ulanzi优篮子VL119RGB棒灯：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwQHXFdbDUkTC18IGloSWwUEV11dAEkRAV9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmgOGF0WXgYKVlhfFxJSXzI4cB8UNkFDAAg9DgtPfh1qYTIPBXMHNFJROEonAG4KG1IUWQIHXG5tCEwnQgEIGF8QXgMEVm5cOEsRAmoJG1odWgQEXVxtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLXVlfCEgUA3MIGlITXQUeVFhcDUoXAmcMElwdWzYAVV9ZAXsnM2kMG1tyCHZaJCcICAlqR2d2Hj5dX21pAzBfTxhyYjJRaBJlG3VJDSI0bR0n)

● <font color="#FF8C00">Ulanzi优篮子VL49RGB补光灯：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAY8JK1olXwMCXV9aAE4UA18IGloUXQIKXVxfDEonRzBQRQQlBENHFRxWFlVMWzBeTA9KQl1XSwwDVFVPRjtUBAJQAVsMFgQZBEsWAm4IH1McXwQGVUkdBD9ucwp_aDhWK39UNCkUew9vdgh7eQF1X3BgXTs_US9TYxpzaDlcKU11NlYqbDhvAQ9QEyx3B2VFIjclbzB0YCp8GQF2KU91CipcfxZCejFSfTkdK3JhNAAlcRFEdzZrXyxKKWZ2Jj5JCj4nYjVQQjwUCU9gBjwbXjlTWRhhTS9FCwoOZF9tC0oVA2YJH18QVTYyVFltSiVTXj9XUAPM653b9cqKru3Ouu7ckP0lXDYCUl9YCUsWC2YAHFkdbQECXW4bXBRSWz9XXQ9KM1oyZG5eOEwXCnsOaRpHSQBwZG5dC3sUM28JG1IcWgQCV15UFEsXBGoAH0cVWwcHVV5cAEITC2oOK1kUXAILZG5tej1wXDlfXSlTPXVlACYufzRERGpBTwVXMwR0LRk6fzB-VSlDSAZqGwUAKm4)

● <font color="#FF8C00">Toprig S40电动滑轨：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwQAVFpZCEMXAF8IGloTWQQGVVdVCEwVCl9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmkMGV8UVA4CU1xUFxJSXzI4eF9DKEJLBh04Uxsee2xfZQdtB0NEAlJROEonAG4KG1IUWQIHXG5tCEwnQgEIGF8cXgQFUm5cOEsRAmoJG1sUXgUGV19tD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLUlpfAUMeCnMIGFoTVAceVFhcDUoXA24IH10QXjYAVV9ZAXsnMxhjbQ5HD1VpBz1UfjttZB8JZjJQFEVgVjBfbzh-dxR2XAVGDVlVAgBaTD8n)

● <font color="#FF8C00">爱图仕艾蒙拉T2C RGB棒灯：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAbIJK1olXQMFU1dYCE8XAF8IGloRXAADUllaDUwXAl9MRANLAjZbERscSkAJHTRQRA1CCVkdDwtCWhVLHTdNTwcKBENeCVAfUg8bA24JH1oTXAAFU1taCEoAQ2N8YitwKWVlFSo0WixjWhhWbyJlBWJhJBgqQBFyYW50XS9OLWBlDToUaAMWYQ1BGht2FVxnNl8pTitPZBx8eBJCKX9-NCcufwpjXDlsYDxpW2NKNyg6VxV_UQl0cjgUNlhhPT0vfChRF2x_bxN9NH9mKFcrcSt0dG50EztdJnB2VQsDayloehhQeARjNFBSIz02Vjx-ezc4WBNuPlBqFSo_CClXRhVRfydhPnpAAlJROEonAG4KG1IUWQIHXG5tCEwnQgEIGloVWgIHV25cOEsRAmoJG1sUWQUDUFdtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM28LK1glXQcCXFpcDUofBWkUG1kTXg4HSF5bCU4WA28JHl0VWgAyVl9cDEInM19PQDhSWGd0KihbACh2ZhptRQ1-GXN6BBczCk0VaBNhZgBgK1x3K18aSj5rMw)

● <font color="#FF8C00">云腾691单反三脚架：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQYJK1olXwQAVFxeCEMeCl8KE18TWQ4AXFpVC3tTXDdWRGtMGENDFlVDFhNSVzMXQA4KD1heSlxVDE0TC20AH1MWQl9HCANtT0pIdGdBbCN1VHBAJDwAaxgeZDBse1cZbQcyV19fCEIWB2sNE2slXQEyFTBdCUoRB20NGmsUbQYEVVtcCEsWBWkBGFklWgYLZBgJVw5PUzBOTwR7ATYyZF1tD0seF2l6WgkBW3QyZF5tC3sXAm8BH1wTVQICUkJdDEMVC2cUG10UWAcCVF9bCkwTAl8KGloRVDYyZFwCbi8SUBJBZj9eO31GDQ1eCiplSwhRRTUXD0FjN1dVeAtqeBRwfi5RG0Iy)

<HR>

##### **EP107 - 一次装机100台！iVentoy，新一代PXE网启服务器使用指南**

● iVentoy（官网）：https://www.iventoy.com/cn/index.html

<HR>

##### **EP106 - 背在背上的移动数码仓，NAYO SMART ARRIVE双肩包上手体验**

● <font color="#FF8C00">NAYO SMART ARRIVE 双肩背包：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXg8GUVleCUIUBl8IGloSWgIAUF5aAUsSAl9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmgPH1kRXQELVFtcFxJSXzI4HiN-XE9-Dg0_dANoRhx9UwhxW3ZdAlJROEonAG4KG1IUWQIHXG5tCEwnQgEIG1IcXAUGVW5cOEsRAmoJG1sVXgADVlhtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYKV1tfCUMeBnMIG1MdWAYeVFhcDUoXA28LG1sUWzYAVV9ZAXsnMyhTeBwQPHB8IlhVaypgUTlwTTBRNVB8PzBfDkl8fwZ1QC5jB2N7KzleDjcn)

<HR>

##### **EP105 - iOS设备通用，利用UTM虚拟机，给iPhone、iPad安装Windows**

● AltStore（官网）：https://altstore.io

● Altinstaller：https://pan.quark.cn/s/96d58c9aa2f6 （提取码：m4Z4）

● AltStore（GitHub）：https://github.com/altstoreio/AltStore

● UTM安装包：https://pan.quark.cn/s/88c2dc12391f （提取码：Pm7L）

● UTM SE安装包：https://pan.quark.cn/s/52c66a2bf4a0 （提取码：JyBw）

● UTM（GitHub）：https://github.com/utmapp/UTM

● 爱思助手（官网）https://www.i4.cn

● Lizip整合的Windows8：https://pan.quark.cn/s/549e04c9c7e9 （提取码：8Hqu）

● Lizip UTM整合第一弹（专栏）：https://www.bilibili.com/read/cv18221663

● Lizip UTM整合第二弹（专栏）：https://www.bilibili.com/read/cv19261926

● Lizip UTM整合第三弹（专栏）：https://www.bilibili.com/read/cv21538128

<HR>

##### **EP104  - 所有机型通用，利用Limbo虚拟机，给手机安装Windows**

● Limbo模拟器增强汉化版：https://pan.quark.cn/s/bfefde6842b7 （提取码：an47）

● ZArchives Pro：https://pan.quark.cn/s/c12824d01a4f （提取码：kH7k）

● Tiny Win7精简版系统：https://pan.quark.cn/s/7ce032077845 （提取码：dqx9）

● Tiny XP精简版系统：https://pan.quark.cn/s/25130dc8555c （提取码：ZxRU）

○ 以下是需要敲的代码：

```
-smp 8,cores=8 -drive file=fat:rw:/storage/emulated/0/Download/临时文件
```



<HR>

##### **EP103 - 长时间久坐，为何不让自己的腰舒服一点？黑白调E3人体工学椅使用体验**

● <font color="#FF8C00">黑白调E3人体工学椅：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARAJK1olXwMCUlpYCkseAV8IGloUWQ8GVVZYCEwnRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWB2YMGlMQXQEdDRsBVXseGWdzHQBVNGQAFFcvTDhcUSZOGSFDUQoyVW5eCUkXCm4MH14dbTYCU24fZhJDWzxYQw5NDVhJEV1cCEMnAl8IHVoQXAYCVFpfDEIeM2gIEmtTCVlHDA4CTh9IbTM4K2sWbQECXUpbegpFF2l6K2sVbQUyVF9dAE8WAWcKHVIJXQcDUV1UFEsRAmoJG1sVWQcLUldtCkoWB2Y4K2sVO1tJUgYjWjUQczJtcydKFlJBAiQZekN5AQpgWCFTIkRiKh8JYAx3cDFRKw)

<HR>

##### **EP102 - 可能是维护功能最强大的PE，USBOS使用指南**

● USBOS标准版：https://pan.quark.cn/s/f752710e12a6 （提取码：7eGs）

● USBOS增强版：https://pan.quark.cn/s/3a21e1944777 （提取码：7TXj）

● PETOOLS小工具集（天翼云）：https://cloud.189.cn/web/share?code=aMvE3uVVFFZz （访问码：4dby）（解压密码：zxmls，解压出来的pdf文件改后缀名为7z再解压一次）

<HR>

##### **EP101 - 游戏玩家的第一台电竞投影仪？雷神F1上手体验**

● <font color="#FF8C00">雷神F1投影仪：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAYYJK1olXwMCXVtYCk8VAF8IGloUWQYEVlpVCUgnRzBQRQQlBENHFRxWFlVMWzBeTA9KQl1XSwwDVFVPRjtUBAJQAVsMFgQZBEsWAm4MG10XWQ4DV0kdBD9ucwp_aChSKll-Mic-bwlvdgtheQJpX2VwXCg_UjtTdRpweDkUKU12HFc5bD93ARtQEjl3B3oENycPWDB0YCp8GSNzKl91EypcfxZCejFSbC5MIXFYNx4lcT9ydyZBRyxsOWJ1Jz0KOAtjdw1BbAd8PUZ4BzcPdlETc2trZjsZUTYDZF1cCkseAmsMHlMlbQYFZA0z0OGR1funzOCxiYqCV11tCXsXBW4NGlsVXQ4DV11VOEwXCl9OTwRQBVZdEgoCZhcnM18LK1wVVBIEJh8PHE1lM18IGGsWbQYDVFdVDE4RBW4JB1sUXAIDU0JdDkoSAm8IG1IRXw4EZFxcCU8eM184QQhvWEcAADkJfBJtBRN_UhsVOmdwATVcZkkeBwhTQlsUWVJxVDwZczBXXl8)

<HR>

##### **EP100 - 小白的第一款一键重装工具，EasyRC使用体验**

● EasyRC官网：https://firpe.cn/page-196

● EasyRC：https://pan.quark.cn/s/6c2523d2ad26 （提取码：dQ8v）

<HR>

##### **EP99 - 投影仪色彩新标杆，明基W1800上手体验**

● <font color="#FF8C00">明基W1800投影仪：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARMJK1olXwQAVVlcDEgRBF8IGloUXQIDVVdcD0MnRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWA2sJGlIUWg4dDRsBVXsWfioWGEVeI2NACBoleyBDSxAPXh1TUQoyVW5eCUkXCm4MH14dbTYCU24fZhhDXC_fsuTB843V7_qJhMvAruQ4GmsVWwcHVV5dC0gSAmwJK1wVVDZEAAEYUBtIRTtXdQclbTYBZFldAV8RcS5aD11nbTYCZF1tCEoXCmgIHVgUXQ4eVFldDUkWH28OGl4UXQYBVFldDEsnAW4JH1IlbTZmKjgfXiJufBZ_Wj1wKVxULjgAUChwXmlmGVodAGZbHzwUcQtxSwcLfF5cbQ)

<HR>

##### **EP98 - 给玩客云刷入Armbian，安装易有云，变身私人网盘**

● Armbian固件（Github）：https://github.com/hzyitc/armbian-onecloud/releases

● Armbian固件：https://pan.quark.cn/s/df1a4b42ca1b （提取码：WhgB）

● 晶晨烧录工具：https://pan.quark.cn/s/7de50fb2a8e5 （提取码：sSut）

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html

○ 以下是需要敲的代码：

#编辑软件源

```
nano /etc/apt/sources.list
```

#清华大学源

```
deb https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main contrib non-free

# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main contrib non-free

deb https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main contrib non-free

# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main contrib non-free

deb https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-backports main contrib non-free

# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-backports main contrib non-free

deb https://mirrors.tuna.tsinghua.edu.cn/debian-security bullseye-security main contrib non-free

# deb-src https://mirrors.tuna.tsinghua.edu.cn/debian-security bullseye-security main contrib non-free
```

#更新系统及软件

```
apt-get update && apt-get upgrade
```

#新建目录，CD后可为任意目录

```
cd /home
```

#确认

```
ls
```

#下载易有云（可根据官网软件版本自行修改后边的链接）

```
wget https://fw0.koolcenter.com/binary/LinkEase/LinuxStorage/linkease-binary-1.1.9.tar.gz –no-check-certificate
```

#解压安装包（需对应你下载的软件版本）

```
tar -zxvf linkease-binary-1.1.9.tar.gz
```

#查看解压后的文件并进入该目录（需对应你下载的软件版本）

```
cd linkease-binary-1.1.9
```

#赋予程序权限

```
chmod 755 linkease.arm
```

#运行易有云

```
./linkease.arm
```

<HR>

##### **EP97 - 简单好用，小白的第一款4盘位NAS，绿联DX4600上手体验**

● <font color="#FF8C00">绿联DX4600：</font> [点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAYsJK1olXwMBU19YCEweB18IGloUXw4LXV9eCEsnRzBQRQQlBENHFRxWFlVMWzBeTA9KQl1XSwwDVFVPRjtUBAJQAVsMFgQZBEsWAm4KE1IcXAUCVEkdBD9ucwp_aDBKK29UMSkEawxvdgtbeQJ1X3JwXCc_UTNTdApwezlcG012HFcNbD9FAQxAEyt3B3lHNBYpbjB0YCp_YglwKl9hCyg5fxZCejFUfDlQNnJ1KFclcT9yehxBWy98OWB1Jz0KOCINZAd4UBhRP1haLVpeAC1kSw5tQR0ZUTYDZF1cCkseAmsMHlMlbQYFZBwz3sGZ2t-tB4y91t-w2IrBoZ-kml8JK1sTXAMDVF5eDU4RAGs4HFscbUBWCxsFWBRRVzBmR2slbQUyU15UHE1lQj0cHSklbQYBZF1tCEoXCmkLHVkdVAQeVF9fDUwVH28OGl4UXQYBUV5UC0InAW4JH1IlbTZ6NSM4USoeZWZBRSZ0HHlbBz4CSzVEcxJmGV4UAkJmEC0IAQ13cT1cGFJCbQ)

<HR>

##### **EP96 - 时代的眼泪，给玩客云刷安卓系统，变身电视盒子**

● 英菲克固件：https://pan.quark.cn/s/fbacbad6cd1e （提取码：bsfh）

● 晶晨烧录工具：https://pan.quark.cn/s/7de50fb2a8e5 （提取码：sSut）

<HR>

##### **EP95 - 一步到位三系统，给HK1BOX刷入Android+HybirdELEC到闪存，变身电影游戏神器**

● Android+HybirdELEC三合一线刷包（Github）：https://github.com/7Ji/HybridELEC/tree/android-burning

● Android+HybirdELEC三合一线刷包（无需解压）：https://pan.quark.cn/s/43ef4dafb1ea （提取码：YFPm）

● 三系统切换小工具（Github）：https://github.com/7Ji/HybridELEC_Rebooter

● 三系统切换小工具：https://pan.quark.cn/s/0787edd1c669 （提取码：ZDMn）

● 晶晨烧录工具：https://pan.quark.cn/s/7de50fb2a8e5 （提取码：sSut）

<HR>

##### **EP94 - 支持多种机型，给电视盒子刷入OpenWRT，变身软路由**

● OpenWRT固件（多种机型）：https://pan.baidu.com/s/1BIjHHfi90Oa7Le91Q8gkOg （提取码：02im）

● OpenWRT固件（HK1专用）：https://pan.quark.cn/s/477785a15060 （提取码：rrUj）

● BalenaEtcher（官网）：https://www.balena.io/etcher

○ 需要加入防火墙的自定义代码：

```
iptables -t nat -I POSTROUTING -o eth0 -j MASQUERADE
```

● <font color="#FF8C00">奥睿科UFSD快闪U盘（128G）：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQoJK1olXwQBXFZcAUwRA18IGloRVQELUlxdDEoWAF9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmsAHFITXwYGVV9eFxJSXzI4Uj8QIlRFDSU4XBsRVg9cUiZIIHlfJFJROEonAG4KG1IUWQIHXG5tCEwnQgEIGFwdWAIyVW5dDkoSAm8IGF0QVA8LZFldAXtRVzBNQwtKG1JdOgJtOHsUM2gIEk8TL0dQQFgvOHsXM2w4G1oVVQQDVl5UCkoLA24JH1wUQQYEVVtcCEsUBW8BGVwlXwcDUFdtOHseABd-Y1pAIVNqESYJaQJsZgp3Z1gSNHNsVgQAdxweZy9uTlpoIkZGEAFaOA)

<HR>

##### **EP93 - ChatGPT国内平替，免费使用，无需注册，响应快**

● 微信小程序搜索：魔瓶ai，即可免费使用，无限对话，响应速度很快

● 小程序界面点击反馈按钮，可以加入魔瓶AI社区，和大家交流自定义AI机器人制作心得

<HR>

##### **EP92 - 电视盒子刷废了？教你强刷救砖固件，抢救变砖的盒子**

● 晶晨烧录工具：https://pan.quark.cn/s/7de50fb2a8e5 （提取码：sSut）

● 智能电视论坛：https://www.znds.com

● 开心电视网：http://www.kaixindianshi.com

● 恩山无线论坛：https://www.right.com.cn/forum

● XDA：https://forum.xda-developers.com

● 油管：https://www.youtube.com

<HR>

##### **EP91 - 支持多种机型，给电视盒子刷入Armbian，变身迷你电脑，实现轻办公**

● Armbian Github项目页：https://github.com/ophub/amlogic-s9xxx-armbian

● Armbian Github机型支持列表：https://github.com/ophub/amlogic-s9xxx-armbian/blob/main/README.cn.md

● Armbian Github 软件列表：https://github.com/ophub/amlogic-s9xxx-armbian/blob/main/build-armbian/documents/armbian_software.md

○ Github可能有部分地区的网络没办法访问，请自备魔法环境

● BalenaEtcher：https://www.balena.io/etcher

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

<HR>

##### **EP90 - 一个浏览器插件承包所有摸鱼时间，办公室划水利器，还能白嫖ChatGPT**

● WeTab新标签页插件官网：https://www.wetab.link/zh

<HR>

##### **EP89 - 4款装机必备的WinPE推荐，纯净、好用、无广告**

● 朝阳PE（官网）：http://wintogo-lzp.freeee.ml

● 朝阳PE：https://pan.quark.cn/s/cef0214b105f （提取码：cpMw）

● 冰封PE（官网）：http://www.bfgho.com

● 冰封PE：https://pan.quark.cn/s/999070929683 （提取码：Vp7L）

● CMDPE（官网）：https://www.cmdpe.com

● CMDPE：https://pan.quark.cn/s/7740070851a3 （提取码：kCH2）

● 无垠PE：https://pan.quark.cn/s/b49c52b38804 （提取码：mAHA）

<HR>

##### **EP88 - 8Gen2玩模拟器游戏怎么样？iQOO11模拟器游戏实机评测**

● PPSSPP（模拟器）：https://www.ppsspp.org

● Cirta（模拟器）：https://citra-emu.org/download

● Dolphin（模拟器）：https://cn.dolphin-emu.org/download

● AetherSX2（模拟器）：https://www.aethersx2.com/archive

● AetherSX2（模拟器）BIOS合集：https://pan.quark.cn/s/1e3f5d3264d8 （提取码：qTqs）

● 蛋蛋（模拟器）整合版：https://pan.quark.cn/s/896baea0261c （提取码：vuYE）

● Exagear（模拟器）：https://pan.quark.cn/s/2f39626fae22 （提取码：iJax）

<HR>

##### **EP87 - 什么？你还用着Ventoy的默认主题？快来看看它的美化教程吧**

● Ventoy官网下载：https://www.ventoy.net/cn/download.html

● GRUB主题下载（可能需要魔法）：https://www.gnome-look.org

● 莫老师的Ventoy主题：https://pan.quark.cn/s/69679fa2b165 （提取码：b48k）

<HR>

##### **EP86 - PS5+投影仪，用主机游戏在客厅霸屏，是种什么神仙体验？**

● <font color="#FF8C00">明基TK700ST（家用投影仪）：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARMJK1olXwMBUFpaCk8VBF8IGloUXQUFVFpeD0knRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWA2wPG18WWgQdDRsBVXteZiZyYllyLmV_MlwPSxB8YBRSeS5DUQoyVW5eCUkXCm4MH14dbTYCU24fZhhDXC_fsuTB843V7_qJhMvAruQ4GmsVWwcHVV5dCkofBmsPK1wVVDZEAAEYUBtIRTtXdQclbTYBZFldAV8RcS5aD11nbTYCZF1tCEoXCmkKH1wXXgQeVF5VDkkTH28OGl4UXQYAVVtdDUsnAW4JH1IlbTZ-JysbWjF3cw97fC4SPg9cFxk9fzVvfxpmGSZ-PWQAEQRbaBhQdGpQXxJnbQ)

<HR>

##### **EP85 - 真 · 一键重装系统！CmzPrep，安装使用指南！**

● CmzPrep下载（不推荐使用）：https://pan.quark.cn/s/5d287282230d （提取码：CxdE）

● EasyRC官网（推荐）：https://firpe.cn/page-196

● EasyRC（推荐）：https://pan.quark.cn/s/6c2523d2ad26 （提取码：dQ8v）

<HR>

##### **EP84 - 可能是颜值最高的多系统引导神器，rEFInd进阶使用指南**

● rEFInd官网：http://www.rodsbooks.com/refind

● rEFInd主题（可能需要魔法）：https://github.com/topics/refind-theme

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

● rEFInd中文说明文档（莫老师翻译）：https://pan.quark.cn/s/eb42e6817be4 （提取码：ZDZx）

● rEFInd中文说明文档（Github）：https://github.com/nixevol/rEFInd-zh_cn

<HR>

##### **EP83 - 手机浏览器也能如此清爽丝滑，教你安装扩展插件，提升上网体验！**

● 狐猴浏览器官网：https://www.lemurbrowser.com

<HR>

##### **EP82 - 莫老师的B站5W粉丝抽奖！感谢大家一直以来的支持**

● <font color="#DB7093">抽奖结果已经在B站动态中公布，请中奖小伙伴尽快与莫老师联系！</font>

<HR>

##### **EP81 - 复古游戏神机？Switch Lite全能模拟器使用指南**

● RetroArch模拟器（官网）：https://www.retroarch.com

● RetroArch模拟器（历史版本和测试版）：http://buildbot.libretro.com/stable/1.14.0/nintendo/switch/libnx

● RetroArch模拟器（前端nsp）：https://pan.quark.cn/s/ff008516b8b5 （提取码：LJ99）

● 阿里巴巴普惠体：https://www.alibabafonts.com/#/home

<HR>

##### **EP80 - Switch特斯拉插件使用指南，金手指、超频、底座转换一键使用**

● 大气层+特斯拉整合包（最新）：https://pan.baidu.com/s/1Aq53TNTUTccNkQRAcg_Y3Q?pwd=xlcj

● 大气层+特斯拉整合包（1.6.2）：https://pan.quark.cn/s/861c576ff095 (提取码：W9as）

● Switch离线固件（最新）：https://darthsternie.net/switch-firmwares

● Switch离线固件（17.0.0）：https://pan.quark.cn/s/c3c37b6e8701 (提取码：CSxC)

<HR>

##### **EP79 - 折腾版Switch Lite入手指南，验机、备份、更新一条龙教程**

● 大气层+特斯拉整合包（最新）：https://pan.baidu.com/s/1Aq53TNTUTccNkQRAcg_Y3Q?pwd=xlcj

● 大气层+特斯拉整合包（1.6.2）：https://pan.quark.cn/s/861c576ff095 (提取码：W9as）

● Switch离线固件（最新）：https://darthsternie.net/switch-firmwares

● Switch离线固件（17.0.0）：https://pan.quark.cn/s/c3c37b6e8701 (提取码：CSxC)

<HR>

##### **EP78 - 托尼老师的御风魔杖，LansamPro零速吹风机上手体验**

● <font color="#FF8C00">LANSAMPRO（零速吹风机）：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXwMBV19dCk8QAF8IGloSXQ4FUVxYAEsUBl9MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmgIE1wQXwMKVF1YFxJSXzI4QCtlDQJ7A1o9bzVQHSh0GxpdOVRlElJROEonAG4KG1IUWQIHXG5tCEwnQgEIGF0UWgcKVG5cOEsRAmoJG1sXWAcCXVZtD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYLXVdfCk4VAnMIH1gWVQceVFhcDUoXA20KHFkQWzYAVV9ZAXsnMx9tfhJVO09XHSMUbREVczULch0WJ05wPTBfbj9RaBdeZD5cWXFhPFZUTgsn)

<HR>

##### **EP77 - 无忧启动大神出品，无需代码，小白也能DIY出属于自己的PE**

● 斗鱼PE生成器（官网）：https://winpemaker.ccpe.net

● 斗鱼PE生成器：https://pan.quark.cn/s/0f6fd7faa802 (提取码：QHSA)

● 沉默的斗鱼（无忧启动论坛）：http://wuyou.net/forum.php?mod=viewthread&tid=432997

● 沉默的斗鱼（B站）：https://space.bilibili.com/1484665709

● Windows原版镜像下载：https://hellowindows.cn

<HR>

##### **EP76 - NAS 路由器二合一？速界Space1私人云存储服务器上手体**

● <font color="#FF8C00">Space1（速界NAS）：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAYAJK1olXwMBVFZaCEMeA18IGloUXw8CVVtbAUknRzBQRQQlBENHFRxWFlVMWzBeTA9KQl1XSwwDVFVPRjtUBAJQAVsMFgQZBEsWAm4KElsUWAALVkkdBD9ucwp_aDBJKX9yPSoUCA5vdgh4eQJ9X3JgXTo_US9TdDRwfDkUKU1iDFc0bDhFAQ9AEj13BG1dICw6ezB0YCp_cit2KU95EylcfxZCei5LbARuJmZlXRwlcRFEehx7RCx8IVZ2Jj5JCj4nUBZ4WFpeNllgLDw1USJ-Sg1JexkQPQoOZF9tC0oVA2YJH18QVTYyVFltSiXPssHev-YlXDYCUl9YCUsXAWkPHlscbQECXW4bXBRSWz9XXQ9KM1oyZG5eOEwXCnsOaRpHSQBwZG5dC3sUM28JG1IcXQYKXFdYFEsQAmgAGEcVWwcHVV5dCk0VBWwOK1kUXAILZG5tbTtHaGp2YB5uFXxSUxYDby5LBBILY1hDMwQCNFlfehJKCxRcRwFSB1xWDW4)

<HR>

##### **EP75 - 可能是颜值最高的多系统引导神器，rEFInd使用教程**

● rEFInd（官网）：http://www.rodsbooks.com/refind

● rEFInd主题（可能需要魔法）：https://github.com/topics/refind-theme

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

○ minimal主题的生效代码（粘贴到refind.conf的最后）：

```
include themes/rEFInd-minimal/theme.conf
```

<HR>

##### **EP74 - 省事不折腾，2分钟，让你的Windows变成MacOS模样**

● MyDockFinder官网：https://www.mydockfinder.com

● MacOS鼠标指针（蓝奏云）：https://wwof.lanzoul.com/ikvDC0mqxh9i (密码:hhxu)

● MacOS鼠标指针：https://pan.quark.cn/s/d9004395f77c (提取码：pzrG)

● MacOS壁纸：https://512pixels.net/projects/default-mac-wallpapers-in-5k/?ref=toolsforyou

● MacOS字体：https://pan.quark.cn/s/20623aa094bc (提取码：fY79)

● Windows主题破解ultrauxthemepatcher：https://pan.quark.cn/s/e10d8bb7fa62 (提取码：1AHq)

<HR>

##### **EP73 - 大小核还能用吗？教你在8-13代酷睿平台安装Win7，以兼容旧软件**

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

● 64位原版Win7镜像：https://hellowindows.cn/

● 64位魔改核显版Win7镜像（来自SMXDIY论坛xiaofeng）：http://www.smxdiy.com/space-uid-2.html  （需要付费）

● 7、8、9代酷睿魔改版核显驱动（来自SMXDIY论坛xiaofeng）：https://pan.quark.cn/s/9d320d5a6800 (提取码：QUra)

● ASUS EZ Installer USB3/NVME注入工具：https://pan.quark.cn/s/74c6f6c31572 (提取码：TyBR)

● 国外大佬USB3.0驱动：[点此访问](https://winraid.level1techs.com/t/outdated-usb-3-0-3-1-drivers-original-and-modded/30871)

<HR>

##### **EP72 - 教你开拖拉机，耕田施肥金坷垃，农业发达全靠它**

● 本期视频没有附件

<HR>

##### **EP71 - 买新不买旧？800元全新显示器vs二手2K价位显示器谁更强**

● 本期视频没有附件

<HR>

##### **EP70 - 作为生产力到底行不行？装了台性价比超低的itx核显小主机**

● 本期视频没有附件

<HR>

##### **EP69 - 可玩性拉满！异地组网、远程控制，蒲公英X5企业级路由器折腾记**

● <font color="#FF8C00">蒲公英X5路由器：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAa4JK1olXQQCVVxfC08TAV8IGloXXw4LVVlaCkwfAF9MRANLAjZbERscSkAJHTRQRA1CCVkdDwtCWhVLHTdNTwcKBENeCVAfUg8bA24JGVkdVAcFU1xaAEgAQ2N8YitwKk9pCyg0eCxjWgRWbSJtBWYDJB0pehF3Yxx8HS1sJWV1JzUffyJ3ZBh8b1NhX2ZRNwciVj1lYwpoeChCKX9-NicufwlgXAdYYDxpW2NKNyg6VxV_UQl0eSJxNQN0PSIOay9kRA96ZzJ2PlNBIiw9bjxOaCh_GTxiPWJhCClfXih0YQxXbTJpOnJhVBopcR1PMxl9c150Xm5gNwwvUyBHeTZ-XSYQPnYOWG5cOEgWAW8BGl8RWA4yZF5aOAp5BW0PGVgXbQcyVFhcDUoXA20AE1IcXTYFVFdtTh9IRjdYRB1BAmheZG5tC3sQA2YcHSlUDxIEJm5tCEgnAF8IGlsdXgYCVVhVCVcXBm0LHV4JXQADUV9dCEkfBWkIHGsXXAcGXW5tOBNRZzJyfD52OGRwMFotT0tfUWoJHQxgA2gAAQlYbQ8WcAttXiBcPHFKMAVt)

<HR>

##### **EP68 - 装系统会更丝滑吗？教你封装一个独特的Windows镜像**

● Windows原版镜像（MSDN i tell you）：https://next.itellyou.cn/

● Windows原版镜像（仓储站）：https://hellowindows.cn/

● NTLite（官网）：https://www.ntlite.com/download

● NTLite：https://pan.quark.cn/s/40cc0e7cf0e0 (提取码：sr7y)

● VM虚拟机：https://customerconnect.vmware.com/downloads

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

● Easy Sysprep：https://pan.quark.cn/s/97dc53d6987c (提取码：D8gs)

<HR>

##### **EP67 - 淘汰的小米盒子不要扔，刷个机就能变身电影游戏神器**

● 晶晨烧录工具：https://pan.quark.cn/s/7de50fb2a8e5 （提取码：sSut）

● HybridELEC固件：https://pan.quark.cn/s/a0cb43114ab9 （提取码：NXtA）

<HR>

##### **EP66 - 程序员能设计出什么背包？NAYO SMART Herman Pro上手体验**

● <font color="#FF8C00">NAYO SMART Herman Pro（双肩背包）：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQwJK1olXg8GUVleCUIUBl8IGloTVQMAUF5eC0sfC19MRANLAjZbERscSkAJHTdNTwcKBlMdBgABFksWAmkAHlkRXQUBVFZVFxJSXzI4aB9eRw9eLDo4DSltGQZ7Ugx3IUIAJFJROEonAG4KG1IUWQIHXG5tCEwnQgEIG1IcXAUGVW5cOEsRAmoJG1sQXwAAVl5tD0seMylcRB5NDVlEAAEzVHsnM2w4HFscSQBwFQxJDjknM284GGsVXAYKVVlbCkkXBXMIG1oXWQUeVFhcDUoXA2oKGF4UXDYAVV9ZAXsnMxdpZj5MPA9kXRcDdTgSAAh0ewRHFW0GHTBfDUpIRwtMaA4cOXkKHBgDARwn)

<HR>

##### **EP65 - 支持多种机型，一键给手机刷入原生ARM版Windows**

● Mindows工具箱官网：https://mindows.cn

<HR>

##### **EP64 - 以雷电PE为框架，改造并DIY一个独属于自己的PE（第二季）**

● 雷电PE（win10内核）：https://pan.quark.cn/s/ddeb92a12ff8 (提取码：stZV)

● 雷电PE（win11内核）：https://pan.quark.cn/s/3b12d0b7564e (提取码：99fB)

● 雷电PE扩展工具：https://pan.quark.cn/s/519088c8844a (提取码：ggem)

● 雷电PE外置扩展工具：https://pan.quark.cn/s/c0207fea2fd4 (提取码：ax3D)

● PETOOLS小工具集（天翼云）：https://cloud.189.cn/web/share?code=aMvE3uVVFFZz （访问码：4dby）（解压密码：zxmls，解压出来的pdf文件改后缀名为7z再解压一次）

● 镜像文件写入U盘小工具：https://pan.quark.cn/s/baa26dced265 （提取码：XANn）

● Dism++：https://pan.quark.cn/s/a977b06e8b28 （提取码：fHKm）

● 软碟通：https://pan.quark.cn/s/2b551c9010ab (提取码：ENNc)

<HR>

##### **EP63 - 从服务端到播放端，Jellyfin硬解及手机、电视的设置**

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html

● MobaXterm：https://pan.quark.cn/s/557a70c52f25 （提取码：tcXR）

● Kodi 安卓客户端：https://kodi.tv/download

● Kodi Jellyfin插件库：https://pan.quark.cn/s/82a2516a82e7 （提取码：wUgh）

● jellyfin 安卓客户端（官网）：https://repo.jellyfin.org/releases/client/android/

● jellyfin 安卓客户端：https://pan.quark.cn/s/994c278ef95b （提取码：wVXX）

● jellyfin 安卓TV客户端（官网）：https://repo.jellyfin.org/releases/client/androidtv/

● jellyfin 安卓TV客户端：https://pan.quark.cn/s/7c9de6e101f5 （提取码：zGsi）

● MX Player（安卓32位）：https://pan.quark.cn/s/cfab3b292065 （提取码：DLaa）

● MX Player（安卓64位）：https://pan.quark.cn/s/3041d5dbb111 （提取码：PqZz）

● jellyfin iOS客户端：https://apps.apple.com/cn/app/id1480192618

● infuse （iOS）：https://apps.apple.com/cn/app/id1136220934

<HR>

##### **EP62 - 利用NAS加Jellyfin打造个人影音库，拯救杂乱的电影文件夹**

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html

● MobaXterm：https://pan.quark.cn/s/557a70c52f25 （提取码：tcXR）

<HR>

##### **EP61 - 刷入OpenWrt变身软路由，红米AX6S路由器折腾记**

● MobaXterm（官网）：https://mobaxterm.mobatek.net/download-home-edition.html

● MobaXterm：https://pan.quark.cn/s/557a70c52f25 （提取码：tcXR）

● AX6S开发版固件1.2.7：https://pan.quark.cn/s/0c795a87a5f4 （提取码：H5mR）

● AX6S Openwrt固件：https://pan.quark.cn/s/9ab7742e45ae （提取码：gkKp）

● WinSCP官网：https://pan.quark.cn/s/2b517154e475 （提取码：zuWN）

● 小米路由器修复工具：https://pan.quark.cn/s/2b06ef93db6f （提取码：SVB5）

● 小米路由器官方刷机教程：
https://web.vip.miui.com/page/info/mio/mio/detail?postId=19134127&app_version=dev.20051

● 小米路由器ROOT密码计算网站：https://blog.isteed.cc/post/miwifi-sshpwd

● 小米路由器ROOT密码计算网站（本地离线版）：https://pan.quark.cn/s/c2fd132315aa (提取码：uRXQ)

○ 获取SSH权限的三条命令（Telnet中输入）：

```
nvram set ssh_en=1& nvram set uart_en=1 & nvram set boot_wait=on & nvram setbootdelay=3 & nvram set flag_try_sys1_failed=0 & nvram setflag_try_sys2_failed=1
```

```
nvram setflag_boot_rootfs=0 & nvram set "boot_fw1=run boot_rd_img;bootm"
```

```
nvram setflag_boot_success=1 & nvram commit & /etc/init.d/dropbear enable &/etc/init.d/dropbear start
```

#刷入Openwrt底包命令（SSH中输入）：

```
mtd -r write /tmp/factory.bin firmware
```

#获取路由器IP命令（CMD中输入）：

```
tracert www.baidu.com
```

<HR>

##### **EP60 - 将Linux To Go塞进Ventoy U盘，与PE、WTG共存**

● Ventoy官网：https://www.ventoy.net/cn/

● Ventoy对Linux发行版本的支持列表：https://www.ventoy.net/cn/plugin_vtoyboot.html

● Ventoy的Linux支持插件：https://github.com/ventoy/vtoyboot/releases

● Ventoy的Linux支持插件：https://pan.quark.cn/s/bcf6dc920e27 （提取码：PUP2）

● VirtualBox虚拟机官网：https://www.virtualbox.org/wiki/Downloads

● Ubuntu官网：https://cn.ubuntu.com/desktop

<HR>

##### **EP59 - 拒绝广告播放器！为装宽带送的盒子刷入原生安卓ATV**

● 当贝OS（天翼云）：https://cloud.189.cn/web/share?code=nymUVvNZfIv2 （访问码：5os5）

● 当贝OS：https://pan.quark.cn/s/2dec133d33f6 （提取码：jxTG）

● ATV（天翼云）：https://cloud.189.cn/web/share?code=qYNRJvNzEvY3 （访问码：xe00）

● ATV：https://pan.quark.cn/s/c652d7444c06 （提取码：QYz9）

● 当贝OS（备用、需要魔法）：https://drive.google.com/drive/folders/13sqHFELH_RNNkeq9ixZTMd7kbdbBeIQU?usp=sharing

● ATV（备用、需要魔法）：https://drive.google.com/drive/folders/1vXbp6HFEbS7o10PbzpBc2YSpYNuBURDV?usp=sharing

<HR>

##### **EP58 - 轻量化系统FydeOS安装体验，稳定流畅兼容安卓，升腾C92折腾记后续**

● FydeOS官网下载：https://fydeos.com/download/

● BalenaEtcher官网：https://www.balena.io/etcher/

● BalenaEtcher：https://pan.quark.cn/s/17121a324d51 （提取码：KNEE）

<HR>

##### **EP56 - 王炸搭档！NAS+投影仪能有多爽？**

● <font color="#FF8C00">明基TK700（家用投影仪）：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BARMJK1olXwMBUFpaCk8VBF8IGloUXgEKUFZcDEwnRzBQRQQlBENHFRxWFlVPRjtUBABAQlRcCEBdCUoWAGgAH1MUWQEdDRsBVXtXamx1HxlGNWYYKhw0dxBHChZhWCNlUQoyVW5eCUkXCm4MH14dbTYCU24fZhhDXC_fsuTB843V7_qJhMvAruQ4GmsVWwcHVV5dDU0UAGcPK1wVVDZEAAEYUBtIRTtXdQclbTYBZFldAV8RcS5aD11nbTYCZF1tCEoXCmcMHl0TXAUeVF5ZCEkRH28OGl4UXQYHUl9YAUsnAW4JH1IlbTZ8MBo7YzF-ZgZ-Wx9JBlhrBiA7aDhkCgRmGThwO1kBEFcNYQ9pQw9vfgtwbQ)

<HR>

##### **EP55 - 刷Bios，装第三方系统，升腾C92瘦客户机折腾记**

● 升腾C92Bios升级文件：https://pan.quark.cn/s/f7a9de9d4967

● IT天空 优启通（官网）：https://www.upe.net/

● IT天空 优启通下载：https://pan.quark.cn/s/eb393e383cb0 （提取码：NzGR）

● 精简版Win10 32位：https://pan.quark.cn/s/5ae64ebff415 （提取码：D5me）

<HR>

##### **EP54 - 把Deepin塞进U盘，即插即用，小白都懂的Linux To Go教程**

● Deepin20.7：https://www.deepin.org/index/zh

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

● 软碟通：https://pan.quark.cn/s/2b551c9010ab (提取码：ENNc)

● Linux Reader（官网）：https://www.diskinternals.com/linux-reader

● Linux Reader：https://pan.quark.cn/s/c9b1c17c1668 (提取码：ZkDM)

● <font color="#FF8C00">奥睿科UFS快闪U盘：</font>[点此查看](https://union-click.jd.com/jdc?e=618%7Cpc%7C&p=JF8BAQkJK1olVQUDXF9UDUwUM28JGlwUWwUBXVxZDUIRMytXQwVKbV9HER8fA1UJWypcR0ROCBlQCgJDCEoWBG4OGFgcXwIHXVhCUQ5LXl8OXgxMGHBCIjsAahlFeihhXRgPP3hUWFJtCXsUAm0IEloRWQMKZG5dD3tWbW8LHFMQWTYDZF5bCU4WA28MGlgcWQIyU15UOA1DXCpQSwRTCVlsCG5tOEgnBG8BD11nHFQWUixtOEsnAF8IGlsdXQcDUFpYAFcXAWgOEloJXQADUV9dCE4fCmoNHGsXXAcGXW5tODN2fgpRelJzVE9cKS1eez5UYzBaaQBPOWgAUV8CTC9TcDoBfyRcCmICJwlt)

<HR>

##### **EP53 - iPhone14标准版上手体验，使用心得及样片分享**

● 本期视频没有附件

<HR>

##### **EP52 - 没想到吧！这名天天搞机的UP主居然是干这个的**

● 本期视频没有附件

<HR>

##### **EP51 - 装宽带送的盒子正在吃灰？插个U盘就能变身复古游戏盒子**

● EmuELEC中文网：https://www.emuelec.cn/

● 人中日月Emuelec镜像包（3.3.1）：https://www.emuelec.cn/355.html

● 各镜像包dtb文件极其对应芯片型号：https://www.emuelec.cn/178.html

● Win32DiskImager：https://pan.quark.cn/s/fa7b5e5ee303 (提取码：QkCw)

● 卡载系统APP：https://pan.quark.cn/s/91cec370c2e7 (提取码：1ggv)

<HR>

##### **EP50 - 无需NAS？用移动硬盘+电视盒子打造纯本地影音库**

● TMM4.2.8：https://pan.quark.cn/s/51d9bfb8ef71 (提取码：iGSj)

● TMM历史版本下载:https://gitlab.com/tinyMediaManager/tinyMediaManager/-/releases

● Kodi下载（官网）：https://kodi.tv/download/

● Kodi下载（中文网）：http://www.kodiplayer.cn/download/

● Kodi皮肤（地平线汉化版）：https://pan.quark.cn/s/1585dd68bef2 (提取码：Qm4Q)

● 站长工具PING：https://ping.chinaz.com/

● TMDB信息刮削地址：api.themoviedb.org

● TMDB图片刮削地址image.tmdb.org

○ Host文件路径：

```
C:\Windows\System32\drivers\etc\host
```

<HR>

##### **EP49 - 装宽带送的盒子正在吃灰？刷个机说不定还能抢救一下**

● 225款电视盒子刷机固件及教程:https://pan.baidu.com/s/1qSmtBgSEbKs6ZFm-yCr-XQ （提取码: nnw3）

● 更多型号可以在此博客搜索获得：https://blog.csdn.net/fatiaozhang9527?type=blog



<HR>

##### **EP48 - 隐藏分区怎么办？如何快速、干净的删除U盘里的PE？**

● DiskGenius：https://pan.quark.cn/s/8e4f3a3d04f7 (提取码：pN75)

<HR>

##### **EP47 - 买 盒 子 记 ！**

● 本期视频没有附件

<HR>

##### **EP46 - 利用雷电PE做框架，改造并自定义一个独属于自己，且稳定好用的PE**

● 雷电PE（win10内核）：https://pan.quark.cn/s/ddeb92a12ff8 (提取码：stZV)

● 雷电PE（win11内核）：https://pan.quark.cn/s/3b12d0b7564e (提取码：99fB)

● 雷电PE扩展工具：https://pan.quark.cn/s/519088c8844a (提取码：ggem)

● 雷电PE外置扩展工具：https://pan.quark.cn/s/c0207fea2fd4 (提取码：ax3D)

● PETOOLS小工具集：https://cloud.189.cn/web/share?code=aMvE3uVVFFZz （访问码：4dby）（解压密码：zxmls）

● 软碟通：https://pan.quark.cn/s/2b551c9010ab (提取码：ENNc)

<HR>

##### **EP45 - 利用DriveDroid将手机打造成运维神器，PE、WTG、Linux统统塞进去**

● 微PE（官网）：www.wepe.com.cn

● 微PE（安装程序）：https://pan.quark.cn/s/3113c12c0888 （提取码：Wz4f）

● 微PE（iSO）：https://pan.quark.cn/s/311a34061700 （提取码：GmK9）

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

● H3PE 下载：https://pan.quark.cn/s/e90bdd2ad247 （提取码：cNCU）

● DriveDroid APP：https://pan.quark.cn/s/d3a040d7ae62 （提取码：dUJv）

● WTG辅助工具：https://pan.quark.cn/s/31094759f122 （提取码：L886）

● 精简版Window10镜像：https://pan.quark.cn/s/898b473d6927 （提取码：RUSA）

● Windows10原版固件：hellowindows.cn

<HR>

##### **EP44 - 纯新手向，小白都能看得懂的PE重装系统教程**

● 系统镜像下载：hellowindows.cn

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

<HR>

##### **EP43 - 流氓PE大体验，捆绑劫持，高速下崽，从装系统抓起！**

● 本期视频没有附件

<HR>

##### **EP42 - 把系统装进内存，小白都懂的RAM OS教程**

● H3PE 下载：https://pan.quark.cn/s/e90bdd2ad247 （提取码：cNCU）

● 一键RAMOS小工具：https://pan.quark.cn/s/e783bb0eca78 （提取码：gYpS）

● 精简版Window10镜像：https://pan.quark.cn/s/898b473d6927 （提取码：RUSA）

<HR>

##### <del>**EP41 - 已丢失的文档**<del>

<HR>

##### **EP40 - 5款WindowsPE系统，纯净，强大，无广告**

● IT天空 优启通（官网）：https://www.upe.net/

● IT天空 优启通下载：https://pan.quark.cn/s/eb393e383cb0 （提取码：NzGR）

● USM U盘魔术师（官网）：https://www.sysceo.com/Software-softwarei-id-129.html

● USM U盘魔术师下载：https://pan.quark.cn/s/4d02d1d10c74 （提取码：jeij）

● USBOS v3.0下载：https://pan.quark.cn/s/64701001f967 （提取码：yZdj）

● USBOS v3.0介绍说明：http://bbs.wuyou.net/forum.php?mod=viewthread&tid=349965&extra=page%3D1

● H3PE 下载：https://pan.quark.cn/s/e90bdd2ad247 （提取码：cNCU）

● H3PE介绍说明：http://bbs.wuyou.net/forum.php?mod=viewthread&tid=370573&extra=page%3D1

● 雷电PE 下载：https://pan.quark.cn/s/25a98719c63b （提取码：KnUu）

● 雷电PE介绍说明：http://bbs.c3.wuyou.net/forum.php?mod=viewthread&tid=426252

● UltraISO软碟通下载：https://pan.quark.cn/s/bd8ebdc99e04 （提取码：QMLA）

<HR>

##### **EP39 - 论文一键降重！公文瞬间纠错！Ai算法加成后的写作工具到底有多强？**

● 秘塔写作猫官网：https://xiezuocat.com/

<HR>

##### **EP38 - 无需Root！无需电脑！用手机就能制作PE启动U盘，应急必备！**

● EtchDroid英文原版：https://pan.quark.cn/s/9005f9ed8396 （提取码：Ku8A）

● EtchDroid汉化版：https://pan.quark.cn/s/f02dc5dc7f4c （提取码：mWNC）

● HikariPE 下载（img）：https://pan.quark.cn/s/2fb2863fa248 （提取码：SDbq）

● HikariPE 下载（iso）：https://pan.quark.cn/s/4f6152172752 （提取码：3q9Q）

● HikariPE 手机启动使用手册：https://hikaripe-sc.hikaricalyx.com/

<HR>

##### **EP37 - 扔掉U盘！将手机制作成WindowsPE启动盘，随身携带！**

● DriveDroid APP：https://pan.quark.cn/s/97de7aa4db3a （提取码：ZD2A）

● 微PE（官网）：www.wepe.com.cn

● 微PE（安装程序）：https://pan.quark.cn/s/3113c12c0888 （提取码：Wz4f）

● 微PE（iSO）：https://pan.quark.cn/s/311a34061700 （提取码：GmK9）

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

● FirPE 手机启动使用手册：https://firpe.cn/page-627

● HikariPE 下载（img）：https://pan.quark.cn/s/2fb2863fa248 （提取码：SDbq）

● HikariPE 下载（iso）：https://pan.quark.cn/s/4f6152172752 （提取码：3q9Q）

● HikariPE 手机启动使用手册：https://hikaripe-sc.hikaricalyx.com/

<HR>

##### **EP36 - 低配版Win To Go?最强Win PE系统Edgeless安装、体验**

● Edgeless（官网）：https://home.edgeless.top

● Edgeless（安装程序）：https://pan.quark.cn/s/549d448d08db （提取码：PcSd）

● Edgeless（iSO）：https://pan.quark.cn/s/2db4b410930c （提取码：4Wja）

<HR>

##### **EP35 - 利用Ventoy打造最强大的启动U盘，把PE、Win To Go统统塞进去**

● U盘：32G以上，64G更佳，4K读写速度最好够快

● Ventoy安装程序：https://www.ventoy.net/cn/index.html

● Ventoy HDV支持插件：https://pan.quark.cn/s/1b88e84add27 （提取码：vUq6）

● WinNT安装程序：https://pan.quark.cn/s/22a968a6d056 （提取码：Snhr）

● EasyBCD引导编辑器：https://pan.quark.cn/s/40e56301449f （提取码：6TPi）

● Windows镜像：https://hellowindows.cn/

● 微PE（官网）：www.wepe.com.cn

● 微PE（安装程序）：https://pan.quark.cn/s/3113c12c0888 （提取码：Wz4f）

● 微PE（iSO）：https://pan.quark.cn/s/311a34061700 （提取码：GmK9）

● Edgeless（官网）：https://home.edgeless.top

● Edgeless（安装程序）：https://pan.quark.cn/s/549d448d08db （提取码：PcSd）

● Edgeless（iSO）：https://pan.quark.cn/s/2db4b410930c （提取码：4Wja）

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

● HotPE（官网）：https://www.hotpe.top

● HotPE（安装程序）：https://pan.quark.cn/s/47e01ddc54c9 （提取码：mY5W）

● HotPE（iSO）：https://pan.quark.cn/s/bc831a39d2d5 （提取码：mKUa）

● 杏雨梨云（官网）：https://www.xyboot.com

● 杏雨梨云（安装程序）：https://pan.quark.cn/s/91fe2c183f28 （提取码：H69W）

● 杏雨梨云（精简版）：https://pan.quark.cn/s/c93f613ba9db （提取码：pqA5）

<HR>

##### **EP34 - 把Windows塞进U盘，即插即用，小白都懂的Win To Go教程**

● Windows镜像下载：https://hellowindows.cn

● WTG辅助工具：https://pan.quark.cn/s/31094759f122 （提取码：L886）

<HR>

##### **EP33 - 5个浏览器插件下载站，无套路、无捆绑、直接下载**

● 插件小屋：https://www.chajianxw.com

● 极简插件：https://chrome.zzzmh.cn

● crx搜搜：https://www.crxsoso.com

● crx4Chrome：http://www.crx4.com

● crx4Chrome：https://www.crx4chrome.com

<HR>

##### **EP32 - 6个电脑文件夹隐藏方法，你或许用得上**

#更改文件夹为系统属性代码：

```
attrib +s +h +r 文件夹路径
```

#更改文件夹标识符代码：

```
我的电脑: {20D04FE0-3AEA-1069-A2D8-08002B30309D}
回收站: {645FF040-5081-101B-9F08-00AA002F954E}
桌面: {00021400-0000-0000-C000-000000000046}
控制面板: {21EC2020-3AEA-1069-A2DD-08002B30309D}
IE: {871C5380-42A0-1069-A2EA-08002B30309D}
网络邻居: {208D2C60-3AEA-1069-A2D7-08002B30309D}
```

● 加密软件VeraCrypt：https://www.aliyundrive.com/s/8QRLLfyjnJ6

<HR>

##### **EP31 - Ventoy，可能是最强大的PE系统、U盘引导工具**

● Ventoy下载地址：https://www.ventoy.net/cn/index.html

<HR>

##### **EP30 - 5款windowsPE系统，纯净、好用、无捆绑**

● 微PE（官网）：www.wepe.com.cn

● 微PE（安装程序）：https://pan.quark.cn/s/3113c12c0888 （提取码：Wz4f）

● 微PE（iSO）：https://pan.quark.cn/s/311a34061700 （提取码：GmK9）

● Edgeless（官网）：https://home.edgeless.top

● Edgeless（安装程序）：https://pan.quark.cn/s/549d448d08db （提取码：PcSd）

● Edgeless（iSO）：https://pan.quark.cn/s/2db4b410930c （提取码：4Wja）

● FirPE（官网）：https://firpe.cn/page-247

● FirPE（安装程序）：https://pan.quark.cn/s/471175649100 （提取码：Mqpk）

● FirPE（iSO）：https://pan.quark.cn/s/832074e296a4 （提取码：mU3G）

● HotPE（官网）：https://www.hotpe.top

● HotPE（安装程序）：https://pan.quark.cn/s/47e01ddc54c9 （提取码：mY5W）

● HotPE（iSO）：https://pan.quark.cn/s/bc831a39d2d5 （提取码：mKUa）

● 杏雨梨云（官网）：https://www.xyboot.com

● 杏雨梨云（安装程序）：https://pan.quark.cn/s/91fe2c183f28 （提取码：H69W）

● 杏雨梨云（精简版）：https://pan.quark.cn/s/c93f613ba9db （提取码：pqA5）

<HR>

##### <del>**EP29 - PanDownload复活版归来（已删除）**<del>

● 因为众所周知的原因删除

<HR>

##### **EP28 - 手机剩余空间不足？如何深度清理手机，让剩余容量翻倍？**

● 安卓端手机QQ清理路径：

```
根目录/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/chatpic
```

● 清浊：https://www.coolapk.com/apk/com.farplace.qingzhuo

<HR>

##### <del>**EP27 - 什么？让我看看还有谁不会玩微信农场！（已删除）**<del>

● 限时热点，已过时

<HR>

##### **EP26 - 5个windows镜像下载站，原版、纯净、精简、无广告**

● MSDN i tell you：https://next.itellyou.cn/

● hellowindows：https://hellowindows.cn/

● 绿色系统：http://lvsexitong.com/

● winos：https://www.winos.me/

● 吻妻出品：https://www.newxitong.com/

<HR>

##### **EP25 - 一部手机用5年？作为835钉子户，我都对手机做了些什么？**

● wesley的小米MIX2固件：https://pan.baidu.com/s/1qp4q6htRv-Wy5FTdxjcUnw?pwd=p6ft （提取码: p6ft）

● 手动调度：https://pan.quark.cn/s/5b89dae14aac （提取码：HZ1e）

● 手动调度使用指南：https://www.jianshu.com/p/c5399a7e9bb3

● yc调度：https://pan.quark.cn/s/1e3e0226a66a （提取码：znAa）

● 冰箱APP：https://www.coolapk.com/apk/com.catchingnow.icebox

<HR>

##### **EP24 - 微软出品的电脑管家？好用吗？**

● 微软电脑管家：https://pcmanager.microsoft.com/cn

<HR>

##### **EP23 - 书虫狂喜！有了这两款阅读神器，安卓和iOS再也不愁书看**

● 阅读3.0（Github）：https://github.com/gedoor/legado/releases

● 阅读3.0：https://pan.quark.cn/s/bb531db733b8 （提取码：keXK）

● 石头阅读（iOS）：APP Store搜索：石头阅读-热门小说阅读器

● 开源阅读：https://gitee.com/zoeybai/read

<HR>

##### **EP22 - 新人UP必读的6条建议，如何快速升级涨粉？如何恰到第一口饭**

●本期视频没有附件

<HR>

##### **EP21 - 教你快速制作一个营销号视频，各种观世界看完直呼内行**

●本期视频没有附件

<HR>

##### **EP20 - 7款浏览器标签页插件，好看又好用，让你的浏览器与众不同**

● Infinity：https://www.infinitytab.com/zh/

● 青柠起始页：https://limestart.cn/

● BD新标签页：https://www.miniits.com/

● MONKNOW：https://www.monknow.com/zh-CN

● 哆咪书签：https://www.domilin.com/

● itab：itab.link

● moontab：https://moontab.pro/

<HR>

##### **EP19 - 被315点名之后，下崽器一夜之间全没了**

● 本期视频没有附件

<HR>

##### **EP18 - 已丢失的文档**

<HR>

##### **EP17 - 游戏崩溃黑屏打不开？PC游戏问题解决指南，专治各种疑难杂症**

● 哈希值校验小工具：https://pan.quark.cn/s/d5f4ca8a0d4e （提取码：Yj1Q）

● 3DM游戏运行库：https://pan.quark.cn/s/f98807f269be （提取码：hLga）

<HR>

##### <del>**EP16 - 白嫖一个月网易云音乐黑胶会员（已删除）**<del>

● 限时活动，已过期

<HR>

##### **<del>EP15 - 俄罗斯学习版网站rutrcker.org后记杂谈（已删除）<del>**

● 请支持正版

<HR>

##### **EP14 - 最简单的PS5/PS4手机游玩教程，小白都能学会**

● 华为应用商店下载地址：https://appgallery.huawei.com/Featured

● TypeC双头数据线淘宝地址：7$ZNBT258Vb4A$://

● PS5手柄手机支架淘宝地址：1$s5nO2584b9R$://

<HR>

##### <del>**EP13 - 比rutracker更强大的俄罗斯学习网站Torrent-xatab（被夹了）**<del>

● 请支持正版

<HR>

##### <del>**EP12 - 5款iOS伪装观影APP（被夹了）**<del>

● 请支持正版

<HR>

##### <del>**EP11 - 俄罗斯学习版网站rutrcker.org（被夹了）**<del>

● 请支持正版

<HR>

##### <del>**EP10 - Clash高危漏洞（被夹了）**<del>

● 请遵守国家相关法律法规

<HR>

##### **EP09 - 杀 毒 软 件 霸 凌 事 件**

● 本期视频没有附件

<HR>

##### **EP08 - 海阔视界保姆级新手使用指南，学会再也不愁找不到资源**

● 海阔视界：https://pan.quark.cn/s/619a3dedd95c （提取码：9qwS）

● 海阔视界（更新地址）：https://pan.quark.cn/s/619a3dedd95c （提取码：9qwS）



<HR>

##### **EP07 - 只要拥有了这5个鬼畜整活网站，你就能整出绝世花活**

● 发音转换器：http://uahh.syouzyo.org/fyzhq

● 抽象话转换器：https://chouxiang.ml/#mdui-dialog

● 静图变动图：https://nodtotherhythm.com/make#

● siri语音生成器：https://cn.piliapp.com/text-to-speech/

● 王斌给您对对联：https://ai.binwang.me/couplet/

<HR>

##### **EP06 - 无聊吗？来这5个网站摸鱼吧！**

● 球球大作战网页版：https://agar.io/

● 太鼓达人网页版（需要魔法）：https://taiko.bui.pm/

● 植物大战僵尸网页版：https://pvz.heheda.top/

● 僵尸增量：https://www.mhhf.com/game/detail/5066

● chrome恐龙小游戏：https://elgoog.im/t-rex/

● EDGE滑雪小游戏：edge://surf/

<HR>

##### **EP05 - 整整5种度盘提速方法！30MB/s带宽拉满，UP实测有效**

● 方法①：修改文件后缀名为.apk，利用文件预览功能高速下载

● 方法②：使用爱奇艺联播的内置网盘功能下载

● ------------爱奇艺万能联播：https://static-s.iqiyi.com/wnbf/get.html

● 方法③：开启百度网盘自带的闲置带宽提速功能

● 方法④：使用第三方网站解析分享连接，获取直链后利用IDM等工具下载

● ------------Kinhdown：https://baidu.kinh.cc/

● ------------极下解析：https://jixia.icu/

● ------------IDM：https://pan.quark.cn/s/21e9c1b8e5fe （提取码：9sXn）

● 方法⑤：利用百度网盘青春版下载

● ------------这破玩意儿自己去手机应用商店下吧

<HR>

##### **EP04 - 没网线，没网卡，教你绕过硬件限制，实现电脑摸鱼自由**

● 本期视频没有附件

<HR>

##### **EP03 - 3个拯救你无聊时间的摸鱼网站，好奇怪，再看一眼**

● 金庸群侠大乱斗：https://zhouxiaobo1990.gitee.io/jyf/

● 宝可梦融合：https://pokemon.alexonsager.net/

● 动物照片艺术参考搜索：https://x6ud.github.io/#/

<HR>

##### **EP02 - 3个停不下来的摸鱼网站！上班族福利、一个破站玩一天**

● RNA进化：https://likexia.gitee.io/evolve/

● 模拟行星运转：http://www.stefanom.org/spc/

● 古董系统模拟器：https://www.pcjs.org/

<HR>

##### **EP01 - 5个每日必刷的摸鱼网站！上班族福利、再也不怕无聊了**

● 今日热榜：https://tophub.today

● 鱼塘热榜：https://mo.fish

● 博海拾贝：https://www.bohaishibei.com

● 福禄吧：https://fuliba2021.net

● 书签地球：https://www.bookmarkearth.com
